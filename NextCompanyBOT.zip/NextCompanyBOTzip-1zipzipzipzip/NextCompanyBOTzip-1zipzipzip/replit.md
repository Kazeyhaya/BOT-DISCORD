# NextCompany Discord Bot

## Overview

A Discord bot built for NextCompany that provides team management, productivity tracking, and entertainment features. The bot integrates with Desk.ms (support ticketing system), includes a Pokemon collection game, scheduled work notifications, AI-powered chat using Google Gemini, and various utility commands.

**Core Features:**
- **Desk.ms Integration**: Real-time webhook notifications for support tickets with operator name resolution and server-side date filtering
- **Pokemon Collection Game**: Capture, evolve, trade, and battle Pokemon with rarity-based mechanics and achievements
- **Work Schedule Management**: Automated messages for work hours, lunch breaks, holidays, and custom reminders
- **AI Chat Assistant**: Context-aware chatbot using Google Gemini API with conversation history
- **Web Search**: DuckDuckGo integration for search queries
- **Team Tools**: Raffle system, random selection tools, and support message generator

## Recent Changes (December 2025)

### Slash Commands Migration
All commands now support modern Discord slash commands (`/command`) with:
- 18 slash commands synchronized
- Autocomplete for Pokemon names, periods, and options
- Backwards compatibility with prefix commands (`!command`)

### Pokemon Game Enhancements
- **Battle System**: Type-based combat with effectiveness multipliers
- **Trade System**: Player-to-player trading with proposal/accept flow
- **Achievements**: 12 different medals for milestones (first catch, 100 catches, full dex, etc.)

### Desk.ms Reports Fix
- Server-side date filtering via API payload (DataCriacao.Inicio/Fim)
- Flexible date parsing supporting multiple formats
- Clear warnings when API limit (3000 records) is reached
- Statistics display with total/filtered/invalid counts

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Application Type
Discord bot application using discord.py with asynchronous HTTP server for webhooks.

### Project Structure
```
├── main.py                 # Entry point
├── bot/
│   ├── workbot.py         # Main bot class with cog loading
│   ├── config.py          # Configuration and environment variables
│   ├── constants.py       # Static messages and constants
│   ├── cogs/              # Feature modules (commands)
│   │   ├── desk.py        # Desk.ms API client
│   │   ├── deskmanager.py # Webhook receiver
│   │   ├── pokemon.py     # Pokemon game logic
│   │   ├── schedule.py    # Work schedule automation
│   │   └── tools.py       # Chat, search, utilities
│   ├── data/
│   │   └── pokemon.py     # Pokemon database
│   └── utils/
│       ├── database.py    # JSON file persistence
│       └── helpers.py     # Utility functions
```

### Architecture Pattern
**Cog-based modular architecture** - Discord.py's cog system separates features into independent modules that can be loaded/unloaded dynamically. Each cog handles a specific domain (Pokemon, scheduling, Desk.ms, tools).

### Data Persistence
**JSON file-based storage** - No traditional database used. All data persists to JSON files:
- `chat_history.json` - Per-user conversation history with AI
- `channel_history.json` - Global channel message history for context
- `pokedex.json` - Pokemon captures per user
- `feriados.json` - Holiday definitions
- `config.json` - Bot configuration (work hours, etc.)
- `sorteo_history.json` - Raffle/lottery history

**Design Decision**: JSON files chosen for simplicity and ease of deployment. No external database dependencies required. Trade-off: Limited scalability and concurrent write capabilities, but acceptable for single-server Discord bot usage.

### HTTP Server Component
**Embedded aiohttp web server** runs alongside the Discord bot to receive webhooks from Desk.ms. Runs on configurable PORT (default 5000).

**Endpoints:**
- `GET /` - Health check
- `POST /deskwebhook` - Receives Desk.ms ticket notifications

**Design Decision**: Single process handles both Discord events and HTTP webhooks, simplifying deployment. Alternative of separate microservices rejected for reduced operational complexity.

### Authentication & Security
- **Discord Bot Token**: Required via `DISCORD_TOKEN` environment variable
- **Desk.ms API Keys**: `DESK_OPERATOR_KEY` and `DESK_ENVIRONMENT_KEY` for API authentication
- **Google Gemini API**: `GEMINI_KEY` for AI chat features
- **SSL/TLS**: Uses certifi for secure HTTPS connections to external APIs

### Async Architecture
Built on Python's asyncio with discord.py. Key async patterns:
- Event-driven Discord message handling
- Concurrent HTTP requests via aiohttp
- Task scheduling for periodic notifications
- Non-blocking webhook processing

### AI Integration
**Google Gemini API** (generative-ai-python package) powers the chat assistant with:
- **Conversation Memory**: Per-user chat history (last N messages)
- **Channel Context**: Global awareness of recent channel conversations
- **Personality System**: Bot configured with Brazilian Portuguese informal tone
- **Safety Settings**: Configured to allow casual conversation

**Design Decision**: Gemini chosen over OpenAI for cost and API simplicity. Chat history stored locally rather than relying on API context to maintain control over memory and reduce token costs.

### Caching Strategy
**In-memory caching** for Desk.ms operator data:
- 1-hour TTL cache for operator ID-to-name mappings
- Reduces API calls during webhook bursts
- Falls back to ID display if cache miss or API failure

### Error Handling
- Graceful degradation: Features continue working if optional APIs (Gemini, Desk.ms) are unavailable
- Comprehensive logging at INFO level for production debugging
- Try-catch blocks prevent single-feature failures from crashing entire bot

### Timezone Handling
Uses `zoneinfo` with "America/Sao_Paulo" (Brazil) timezone for all scheduling features. Ensures accurate work hour notifications regardless of server location.

### Rate Limiting
Custom cooldown system implemented in tools and schedule cogs:
- Per-user, per-command tracking
- Configurable cooldown periods
- Prevents spam and API abuse

## External Dependencies

### Discord Platform
- **discord.py**: Primary bot framework
- **Target Server**: Configured via `DESK_CHANNEL_ID` and `DISCORD_CHANNEL_ID`
- **Role-based Access**: `DISCORD_ROLE_ID` for permission control

### Desk.ms API
- **Purpose**: Support ticket management system integration
- **Base URL**: Configurable via `DESK_API_URL` (default: https://api.desk.ms)
- **Authentication**: API keys required
- **Features Used**: Ticket webhooks, operator lookup, ticket search/details
- **Token Management**: JWT tokens with automatic refresh on expiry

### Google Gemini AI
- **Service**: Google Generative AI (Gemini model)
- **Package**: google-generativeai
- **Purpose**: Natural language chat responses
- **Model**: gemini-1.5-flash (configurable)
- **Configuration**: Safety settings for casual conversation

### DuckDuckGo Search
- **Package**: duckduckgo-search
- **Purpose**: Web search functionality
- **Integration**: Async text search with result summarization

### Pokemon Showdown
- **External Resource**: Pokemon sprite images hosted at play.pokemonshowdown.com
- **Purpose**: Animated GIF sprites for Pokemon cards
- **No API**: Direct image URL references only

### SSL/Certificate Management
- **certifi**: Provides SSL certificates for HTTPS connections
- **Purpose**: Secure communication with all external APIs

### Python Packages
- **aiohttp**: Async HTTP client/server for webhooks and API calls
- **python-dotenv**: Environment variable management
- **Standard library**: asyncio, logging, datetime, json, zoneinfo

### Deployment Requirements
- **Environment Variables**: 6 required (.env file or host config)
- **Port Exposure**: Single port for webhook HTTP server
- **File System**: Write access for JSON data files
- **Python Version**: 3.9+ (requires zoneinfo support)