import discord
from discord.ext import commands
from discord import app_commands
import aiohttp
import ssl
import certifi
import logging

from .config import Config

logger = logging.getLogger(__name__)


class WorkBot(commands.Bot):
    def __init__(self):
        intents = discord.Intents.default()
        intents.message_content = True
        intents.members = True
        super().__init__(command_prefix='!', intents=intents, help_command=None)
        self.session = None
        self.synced = False

    async def setup_hook(self):
        ssl_context = ssl.create_default_context(cafile=certifi.where())
        connector = aiohttp.TCPConnector(
            ssl=ssl_context,
            limit=100,
            limit_per_host=30,
            enable_cleanup_closed=True
        )
        timeout = aiohttp.ClientTimeout(total=30, connect=10, sock_read=20)
        self.session = aiohttp.ClientSession(
            connector=connector,
            timeout=timeout,
            headers={
                "User-Agent": "NextCompanyBot/1.0",
                "Accept": "application/json"
            }
        )

        cogs = [
            'bot.cogs.pokemon',
            'bot.cogs.schedule',
            'bot.cogs.tools',
            'bot.cogs.deskmanager',
            'bot.cogs.desk'
        ]

        for cog in cogs:
            try:
                await self.load_extension(cog)
                logger.info(f"Cog carregado: {cog}")
            except Exception as e:
                logger.error(f"Erro ao carregar {cog}: {e}")

    async def on_ready(self):
        logger.info(f"Bot conectado como {self.user}")
        logger.info(f"Servidores: {len(self.guilds)}")
        
        if not self.synced:
            try:
                synced = await self.tree.sync()
                self.synced = True
                logger.info(f"Comandos slash sincronizados: {len(synced)} comandos")
            except Exception as e:
                logger.error(f"Erro ao sincronizar comandos slash: {e}")

    async def close(self):
        if self.session:
            await self.session.close()
        await super().close()
