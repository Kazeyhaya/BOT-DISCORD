import discord
from discord.ext import commands
from discord import app_commands, ui
import random
import logging
from datetime import datetime
from typing import Optional, List
import asyncio

from ..config import Config
from ..constants import RARITY_COLORS, RARITY_EMOJIS
from ..data.pokemon import POKEMON_DB, get_pokemon_by_name, get_pokemon_by_rarity, get_pokemon_art_url, get_pokemon_card_url
from ..utils.database import JsonDatabase

logger = logging.getLogger(__name__)

ACHIEVEMENTS = {
    "primeiro_pokemon": {"nome": "Primeiro Passo", "desc": "Capture seu primeiro Pokemon", "emoji": "🎯"},
    "dez_pokemon": {"nome": "Colecionador", "desc": "Capture 10 Pokemon", "emoji": "📦"},
    "cinquenta_pokemon": {"nome": "Mestre Colecionador", "desc": "Capture 50 Pokemon", "emoji": "🏆"},
    "cem_pokemon": {"nome": "Lenda Viva", "desc": "Capture 100 Pokemon", "emoji": "👑"},
    "primeiro_lendario": {"nome": "Caçador de Lendas", "desc": "Capture seu primeiro lendário", "emoji": "⭐"},
    "cinco_lendarios": {"nome": "Lenda entre Lendas", "desc": "Capture 5 lendários", "emoji": "🌟"},
    "primeira_evolucao": {"nome": "Evolucionista", "desc": "Evolua seu primeiro Pokemon", "emoji": "🔄"},
    "dez_evolucoes": {"nome": "Mestre Evolucionista", "desc": "Evolua 10 Pokemon", "emoji": "⚡"},
    "primeira_troca": {"nome": "Comerciante", "desc": "Complete sua primeira troca", "emoji": "🤝"},
    "primeira_batalha": {"nome": "Guerreiro", "desc": "Vença sua primeira batalha", "emoji": "⚔️"},
    "dez_batalhas": {"nome": "Campeão", "desc": "Vença 10 batalhas", "emoji": "🏅"},
    "todas_especies": {"nome": "Mestre Pokemon", "desc": "Capture todas as especies", "emoji": "🎖️"},
}

TYPE_ADVANTAGES = {
    "Fire": {"strong": ["Grass", "Bug", "Ice", "Steel"], "weak": ["Water", "Rock", "Ground"]},
    "Water": {"strong": ["Fire", "Ground", "Rock"], "weak": ["Grass", "Electric"]},
    "Grass": {"strong": ["Water", "Ground", "Rock"], "weak": ["Fire", "Ice", "Bug", "Flying", "Poison"]},
    "Electric": {"strong": ["Water", "Flying"], "weak": ["Ground"]},
    "Ice": {"strong": ["Grass", "Ground", "Flying", "Dragon"], "weak": ["Fire", "Fighting", "Rock", "Steel"]},
    "Fighting": {"strong": ["Normal", "Ice", "Rock", "Dark", "Steel"], "weak": ["Flying", "Psychic", "Fairy"]},
    "Poison": {"strong": ["Grass", "Fairy"], "weak": ["Ground", "Psychic"]},
    "Ground": {"strong": ["Fire", "Electric", "Poison", "Rock", "Steel"], "weak": ["Water", "Grass", "Ice"]},
    "Flying": {"strong": ["Grass", "Fighting", "Bug"], "weak": ["Electric", "Ice", "Rock"]},
    "Psychic": {"strong": ["Fighting", "Poison"], "weak": ["Bug", "Ghost", "Dark"]},
    "Bug": {"strong": ["Grass", "Psychic", "Dark"], "weak": ["Fire", "Flying", "Rock"]},
    "Rock": {"strong": ["Fire", "Ice", "Flying", "Bug"], "weak": ["Water", "Grass", "Fighting", "Ground", "Steel"]},
    "Ghost": {"strong": ["Psychic", "Ghost"], "weak": ["Ghost", "Dark"]},
    "Dragon": {"strong": ["Dragon"], "weak": ["Ice", "Dragon", "Fairy"]},
    "Dark": {"strong": ["Psychic", "Ghost"], "weak": ["Fighting", "Bug", "Fairy"]},
    "Steel": {"strong": ["Ice", "Rock", "Fairy"], "weak": ["Fire", "Fighting", "Ground"]},
    "Fairy": {"strong": ["Fighting", "Dragon", "Dark"], "weak": ["Poison", "Steel"]},
    "Normal": {"strong": [], "weak": ["Fighting"]},
}


class TradeView(ui.View):
    def __init__(self, author: discord.Member, target: discord.Member, offer_pokemon: str, request_pokemon: str):
        super().__init__(timeout=120)
        self.author = author
        self.target = target
        self.offer_pokemon = offer_pokemon
        self.request_pokemon = request_pokemon
        self.accepted = False
        self.cancelled = False

    @ui.button(label="Aceitar Troca", style=discord.ButtonStyle.success, emoji="✅")
    async def accept_trade(self, interaction: discord.Interaction, button: ui.Button):
        if interaction.user.id != self.target.id:
            return await interaction.response.send_message("Apenas o destinatário pode aceitar!", ephemeral=True)
        
        self.accepted = True
        self.stop()
        await interaction.response.defer()

    @ui.button(label="Recusar", style=discord.ButtonStyle.danger, emoji="❌")
    async def decline_trade(self, interaction: discord.Interaction, button: ui.Button):
        if interaction.user.id not in [self.author.id, self.target.id]:
            return await interaction.response.send_message("Você não faz parte desta troca!", ephemeral=True)
        
        self.cancelled = True
        self.stop()
        await interaction.response.defer()


class BattleView(ui.View):
    def __init__(self, challenger: discord.Member, opponent: discord.Member):
        super().__init__(timeout=60)
        self.challenger = challenger
        self.opponent = opponent
        self.accepted = False
        self.cancelled = False

    @ui.button(label="Aceitar Batalha", style=discord.ButtonStyle.success, emoji="⚔️")
    async def accept_battle(self, interaction: discord.Interaction, button: ui.Button):
        if interaction.user.id != self.opponent.id:
            return await interaction.response.send_message("Apenas o desafiado pode aceitar!", ephemeral=True)
        
        self.accepted = True
        self.stop()
        await interaction.response.defer()

    @ui.button(label="Recusar", style=discord.ButtonStyle.danger, emoji="🏃")
    async def decline_battle(self, interaction: discord.Interaction, button: ui.Button):
        if interaction.user.id not in [self.challenger.id, self.opponent.id]:
            return await interaction.response.send_message("Você não faz parte desta batalha!", ephemeral=True)
        
        self.cancelled = True
        self.stop()
        await interaction.response.defer()


class RankingView(ui.View):
    def __init__(self, ranking_data: list):
        super().__init__(timeout=120)
        self.ranking = ranking_data
        self.current_page = 0
        self.items_per_page = 10

    def get_pages(self):
        pages = []
        for i in range(0, len(self.ranking), self.items_per_page):
            pages.append(self.ranking[i:i + self.items_per_page])
        return pages

    def get_current_embed(self) -> discord.Embed:
        pages = self.get_pages()
        if not pages:
            return discord.Embed(title="Ranking Vazio", color=discord.Color.red())

        page_data = pages[self.current_page]
        embed = discord.Embed(title="🏆 Ranking Pokemon", color=discord.Color.gold())

        txt = ""
        start_idx = self.current_page * self.items_per_page
        medalhas = ["🥇", "🥈", "🥉"]
        
        for i, player in enumerate(page_data):
            idx = start_idx + i + 1
            medalha = medalhas[idx - 1] if idx <= 3 else f"{idx}."
            lend_txt = f" ⭐{player['lendarios']}" if player['lendarios'] > 0 else ""
            txt += f"{medalha} **{player['nome']}** - {player['total']} capturas, {player['especies']} especies{lend_txt}\n"

        embed.description = txt
        embed.set_footer(text=f"Pagina {self.current_page + 1}/{len(pages)}")
        return embed

    def update_buttons(self):
        pages = self.get_pages()
        for child in self.children:
            if isinstance(child, ui.Button):
                if child.custom_id == 'prev_rank':
                    child.disabled = self.current_page == 0
                elif child.custom_id == 'next_rank':
                    child.disabled = self.current_page >= len(pages) - 1

    @ui.button(label="Anterior", style=discord.ButtonStyle.secondary, emoji="⬅️", custom_id="prev_rank", disabled=True)
    async def prev_rank(self, interaction: discord.Interaction, button: ui.Button):
        if self.current_page > 0:
            self.current_page -= 1
            self.update_buttons()
            await interaction.response.edit_message(embed=self.get_current_embed(), view=self)
        else:
            await interaction.response.defer()

    @ui.button(label="Proximo", style=discord.ButtonStyle.secondary, emoji="➡️", custom_id="next_rank")
    async def next_rank(self, interaction: discord.Interaction, button: ui.Button):
        pages = self.get_pages()
        if self.current_page < len(pages) - 1:
            self.current_page += 1
            self.update_buttons()
            await interaction.response.edit_message(embed=self.get_current_embed(), view=self)
        else:
            await interaction.response.defer()


class PokedexView(ui.View):
    def __init__(self, pokemon_list: list, owner_name: str, owner_id: int):
        super().__init__(timeout=120)
        self.pokemon_list = pokemon_list
        self.owner_name = owner_name
        self.owner_id = owner_id
        self.current_index = 0

    def update_buttons(self):
        for child in self.children:
            if isinstance(child, ui.Button):
                if child.custom_id == 'prev':
                    child.disabled = self.current_index == 0
                elif child.custom_id == 'next':
                    child.disabled = self.current_index >= len(self.pokemon_list) - 1

    def get_current_embed(self) -> discord.Embed:
        if not self.pokemon_list:
            return discord.Embed(
                title=f"Pokedex de {self.owner_name}",
                description="Nenhum Pokemon capturado ainda!",
                color=discord.Color.red()
            )

        poke_name, quantidade = self.pokemon_list[self.current_index]
        poke_info = get_pokemon_by_name(poke_name)

        if not poke_info:
            return discord.Embed(title="Pokemon nao encontrado", color=discord.Color.red())

        raridade = poke_info.get('raridade', 'Comum')
        cor = RARITY_COLORS.get(raridade, 0x95a5a6)
        emoji = RARITY_EMOJIS.get(raridade, '')
        tipo = poke_info.get('tipo', 'Normal')
        evolui = poke_info.get('evolui_para')
        poke_id = poke_info.get('id', 1)

        embed = discord.Embed(title=f"{emoji} {poke_name}", color=cor)
        embed.add_field(name="Tipo", value=tipo, inline=True)
        embed.add_field(name="Raridade", value=raridade, inline=True)
        embed.add_field(name="Quantidade", value=f"x{quantidade}", inline=True)

        if evolui:
            embed.add_field(name="Evolui para", value=evolui, inline=True)
        else:
            embed.add_field(name="Evolucao", value="Forma Final", inline=True)

        if quantidade >= 3 and evolui:
            embed.add_field(name="💡 Dica", value=f"Use `/evoluir {poke_name}` para evoluir!", inline=False)

        embed.set_image(url=get_pokemon_card_url(poke_id))
        embed.set_footer(text=f"Pokemon {self.current_index + 1} de {len(self.pokemon_list)} | Pokedex de {self.owner_name}")
        return embed

    @ui.button(label="Anterior", style=discord.ButtonStyle.secondary, emoji="⬅️", custom_id="prev", disabled=True)
    async def prev_btn(self, interaction: discord.Interaction, button: ui.Button):
        if interaction.user.id != self.owner_id:
            return await interaction.response.send_message("Essa Pokedex nao e sua!", ephemeral=True)

        if self.current_index > 0:
            self.current_index -= 1
            self.update_buttons()
            await interaction.response.edit_message(embed=self.get_current_embed(), view=self)
        else:
            await interaction.response.defer()

    @ui.button(label="Proximo", style=discord.ButtonStyle.secondary, emoji="➡️", custom_id="next")
    async def next_btn(self, interaction: discord.Interaction, button: ui.Button):
        if interaction.user.id != self.owner_id:
            return await interaction.response.send_message("Essa Pokedex nao e sua!", ephemeral=True)

        if self.current_index < len(self.pokemon_list) - 1:
            self.current_index += 1
            self.update_buttons()
            await interaction.response.edit_message(embed=self.get_current_embed(), view=self)
        else:
            await interaction.response.defer()

    @ui.button(label="Lista", style=discord.ButtonStyle.primary, emoji="📋", custom_id="list")
    async def list_btn(self, interaction: discord.Interaction, button: ui.Button):
        if interaction.user.id != self.owner_id:
            return await interaction.response.send_message("Essa Pokedex nao e sua!", ephemeral=True)

        total = sum(qtd for _, qtd in self.pokemon_list)
        especies = len(self.pokemon_list)

        txt = "\n".join([f"**{nome}**: x{qtd}" for nome, qtd in self.pokemon_list[:15]])
        if len(self.pokemon_list) > 15:
            txt += f"\n... e mais {len(self.pokemon_list) - 15} especies"

        embed = discord.Embed(
            title=f"📋 Pokedex de {self.owner_name}",
            description=f"**Total capturados:** {total}\n**Especies unicas:** {especies}\n\n{txt}",
            color=discord.Color.red()
        )
        await interaction.response.edit_message(embed=embed, view=self)


class PokemonCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.pokemon_atual = None
        self.cooldowns = {}
        self.pending_trades = {}
        self.battle_stats = {}
    
    def _load_stats(self) -> dict:
        return JsonDatabase.load("pokemon_stats.json", {})
    
    def _save_stats(self, stats: dict):
        JsonDatabase.save("pokemon_stats.json", stats)
    
    def _check_achievement(self, user_id: str, achievement_id: str) -> bool:
        stats = self._load_stats()
        user_stats = stats.get(user_id, {})
        achievements = user_stats.get("achievements", [])
        return achievement_id in achievements
    
    def _grant_achievement(self, user_id: str, achievement_id: str) -> Optional[dict]:
        if self._check_achievement(user_id, achievement_id):
            return None
        
        stats = self._load_stats()
        if user_id not in stats:
            stats[user_id] = {"achievements": [], "battles_won": 0, "trades_completed": 0, "evolutions": 0}
        
        stats[user_id]["achievements"].append(achievement_id)
        self._save_stats(stats)
        
        return ACHIEVEMENTS.get(achievement_id)
    
    def _check_and_grant_achievements(self, user_id: str, pokedex: dict) -> List[dict]:
        new_achievements = []
        user_data = pokedex.get(user_id, {})
        capturas = user_data.get("capturas", [])
        total = len(capturas)
        
        lendarios = sum(1 for p in capturas if any(pk['nome'] == p and pk['raridade'] == 'Lendario' for pk in POKEMON_DB))
        especies = len(set(capturas))
        
        if total >= 1:
            ach = self._grant_achievement(user_id, "primeiro_pokemon")
            if ach: new_achievements.append(ach)
        if total >= 10:
            ach = self._grant_achievement(user_id, "dez_pokemon")
            if ach: new_achievements.append(ach)
        if total >= 50:
            ach = self._grant_achievement(user_id, "cinquenta_pokemon")
            if ach: new_achievements.append(ach)
        if total >= 100:
            ach = self._grant_achievement(user_id, "cem_pokemon")
            if ach: new_achievements.append(ach)
        if lendarios >= 1:
            ach = self._grant_achievement(user_id, "primeiro_lendario")
            if ach: new_achievements.append(ach)
        if lendarios >= 5:
            ach = self._grant_achievement(user_id, "cinco_lendarios")
            if ach: new_achievements.append(ach)
        if especies >= len(POKEMON_DB):
            ach = self._grant_achievement(user_id, "todas_especies")
            if ach: new_achievements.append(ach)
        
        return new_achievements

    def check_cooldown(self, user_id: int, command: str, seconds: int) -> bool:
        key = f"{user_id}_{command}"
        now = datetime.now()
        if key in self.cooldowns:
            if (now - self.cooldowns[key]).total_seconds() < seconds:
                return False
        self.cooldowns[key] = now
        return True

    def get_cooldown_remaining(self, user_id: int, command: str, seconds: int) -> int:
        now = datetime.now()
        key = f"{user_id}_{command}"
        if key in self.cooldowns:
            last_use = self.cooldowns[key]
            remaining = seconds - (now - last_use).total_seconds()
            if remaining > 0:
                return int(remaining)
        return 0

    async def pokemon_autocomplete(self, interaction: discord.Interaction, current: str) -> List[app_commands.Choice[str]]:
        uid = str(interaction.user.id)
        pokedex = JsonDatabase.load(Config.FILES['pokedex'], {})
        
        if uid not in pokedex or not pokedex[uid].get("capturas"):
            return []
        
        capturas = pokedex[uid]["capturas"]
        contagem = {}
        for pokemon in capturas:
            contagem[pokemon] = contagem.get(pokemon, 0) + 1
        
        nomes = sorted(contagem.keys())
        
        if current:
            nomes = [n for n in nomes if current.lower() in n.lower()]
        
        return [app_commands.Choice(name=f"{nome} (x{contagem[nome]})", value=nome) for nome in nomes[:25]]

    @app_commands.command(name="pokemon", description="Encontrar um Pokemon selvagem")
    async def slash_pokemon(self, interaction: discord.Interaction):
        if not self.check_cooldown(interaction.user.id, 'pokemon', 30):
            remaining = self.get_cooldown_remaining(interaction.user.id, 'pokemon', 30)
            return await interaction.response.send_message(f"⏳ Aguarde {remaining}s para chamar outro Pokemon.", ephemeral=True)

        chance = random.randint(1, 100)
        if chance <= 3:
            pool = get_pokemon_by_rarity('Lendario')
        elif chance <= 15:
            pool = get_pokemon_by_rarity('Epico')
        elif chance <= 40:
            pool = get_pokemon_by_rarity('Raro')
        else:
            pool = get_pokemon_by_rarity('Comum')

        poke = random.choice(pool)
        self.pokemon_atual = poke

        cor = RARITY_COLORS.get(poke['raridade'], 0x95a5a6)
        emoji = RARITY_EMOJIS.get(poke['raridade'], '')

        embed = discord.Embed(
            title=f"{emoji} Um {poke['nome']} selvagem apareceu!",
            description=f"**Raridade:** {poke['raridade']}\n**Tipo:** {poke.get('tipo', 'Normal')}\n\nUse `/pokebola` para capturar!",
            color=cor
        )
        embed.set_image(url=get_pokemon_card_url(poke['id']))
        await interaction.response.send_message(embed=embed)

    @app_commands.command(name="pokebola", description="Tentar capturar o Pokemon selvagem")
    async def slash_pokebola(self, interaction: discord.Interaction):
        if not self.pokemon_atual:
            return await interaction.response.send_message("❌ Nenhum Pokemon para capturar! Use `/pokemon` primeiro.", ephemeral=True)

        poke = self.pokemon_atual
        chances = {'Comum': 70, 'Raro': 50, 'Epico': 30, 'Lendario': 10}
        chance = chances.get(poke['raridade'], 50)

        if random.randint(1, 100) <= chance:
            pokedex = JsonDatabase.load(Config.FILES['pokedex'], {})
            uid = str(interaction.user.id)
            if uid not in pokedex:
                pokedex[uid] = {"nome": interaction.user.name, "capturas": []}
            pokedex[uid]["capturas"].append(poke['nome'])
            JsonDatabase.save(Config.FILES['pokedex'], pokedex)
            self.pokemon_atual = None

            new_achs = self._check_and_grant_achievements(uid, pokedex)

            embed = discord.Embed(
                title=f"✨ GOTCHA! Voce capturou **{poke['nome']}**!",
                description=f"Use `/pokedex` para ver sua colecao!",
                color=discord.Color.gold()
            )
            embed.set_image(url=get_pokemon_card_url(poke['id']))
            
            if new_achs:
                ach_text = "\n".join([f"{a['emoji']} **{a['nome']}** - {a['desc']}" for a in new_achs])
                embed.add_field(name="🎉 Nova Conquista!", value=ach_text, inline=False)
            
            await interaction.response.send_message(embed=embed)
        else:
            self.pokemon_atual = None
            await interaction.response.send_message(f"💨 **{poke['nome']}** escapou da pokebola!")

    @app_commands.command(name="evoluir", description="Evoluir um Pokemon (precisa de 3 iguais)")
    @app_commands.describe(pokemon="Nome do Pokemon para evoluir")
    @app_commands.autocomplete(pokemon=pokemon_autocomplete)
    async def slash_evoluir(self, interaction: discord.Interaction, pokemon: str):
        if not self.check_cooldown(interaction.user.id, 'evoluir', 5):
            return await interaction.response.send_message("⏳ Espere 5 segundos antes de evoluir outro Pokemon!", ephemeral=True)

        uid = str(interaction.user.id)
        pokedex = JsonDatabase.load(Config.FILES['pokedex'], {})

        if uid not in pokedex or not pokedex[uid].get("capturas"):
            return await interaction.response.send_message("❌ Voce ainda nao tem Pokemon! Use `/pokemon` para comecar.", ephemeral=True)

        nome_poke = pokemon.title()
        info = get_pokemon_by_name(nome_poke)

        if not info:
            return await interaction.response.send_message(f"❌ Pokemon `{pokemon}` nao encontrado.", ephemeral=True)
        if not info['evolui_para']:
            return await interaction.response.send_message(f"❌ **{nome_poke}** ja esta no nivel maximo!", ephemeral=True)

        qtd = pokedex[uid]['capturas'].count(info['nome'])
        if qtd < 3:
            return await interaction.response.send_message(f"❌ Voce precisa de 3 **{info['nome']}** para evoluir. Tem apenas {qtd}.", ephemeral=True)

        for _ in range(3):
            pokedex[uid]['capturas'].remove(info['nome'])
        novo = info['evolui_para']
        pokedex[uid]['capturas'].append(novo)
        JsonDatabase.save(Config.FILES['pokedex'], pokedex)

        stats = self._load_stats()
        if uid not in stats:
            stats[uid] = {"achievements": [], "battles_won": 0, "trades_completed": 0, "evolutions": 0}
        stats[uid]["evolutions"] = stats[uid].get("evolutions", 0) + 1
        self._save_stats(stats)
        
        new_achs = []
        if stats[uid]["evolutions"] >= 1:
            ach = self._grant_achievement(uid, "primeira_evolucao")
            if ach: new_achs.append(ach)
        if stats[uid]["evolutions"] >= 10:
            ach = self._grant_achievement(uid, "dez_evolucoes")
            if ach: new_achs.append(ach)

        info_novo = get_pokemon_by_name(novo)
        embed = discord.Embed(
            title=f"🔄 Parabens! Seu {info['nome']} evoluiu para **{novo}**!",
            color=discord.Color.gold()
        )
        if info_novo:
            embed.set_image(url=get_pokemon_card_url(info_novo['id']))
        
        if new_achs:
            ach_text = "\n".join([f"{a['emoji']} **{a['nome']}** - {a['desc']}" for a in new_achs])
            embed.add_field(name="🎉 Nova Conquista!", value=ach_text, inline=False)
        
        await interaction.response.send_message(content=f"{interaction.user.mention}", embed=embed)

    @app_commands.command(name="pokedex", description="Ver sua colecao de Pokemon")
    @app_commands.describe(usuario="Usuario para ver a Pokedex (opcional)")
    async def slash_pokedex(self, interaction: discord.Interaction, usuario: Optional[discord.Member] = None):
        target = usuario or interaction.user
        pokedex = JsonDatabase.load(Config.FILES['pokedex'], {})
        uid = str(target.id)

        if uid not in pokedex or not pokedex[uid].get("capturas"):
            if target == interaction.user:
                return await interaction.response.send_message("📭 Sua Pokedex esta vazia! Use `/pokemon` para comecar.", ephemeral=True)
            else:
                return await interaction.response.send_message(f"📭 A Pokedex de {target.display_name} esta vazia.", ephemeral=True)

        lista = pokedex[uid]["capturas"]
        contagem = {}
        for pokemon in lista:
            contagem[pokemon] = contagem.get(pokemon, 0) + 1

        sorted_pokemon = sorted(contagem.items(), key=lambda x: (-x[1], x[0]))

        view = PokedexView(sorted_pokemon, target.display_name, target.id)
        await interaction.response.send_message(embed=view.get_current_embed(), view=view)

    @app_commands.command(name="ranking", description="Ver ranking de capturas de Pokemon")
    async def slash_ranking(self, interaction: discord.Interaction):
        pokedex = JsonDatabase.load(Config.FILES['pokedex'], {})

        if not pokedex:
            return await interaction.response.send_message("📭 Ninguem capturou Pokemon ainda!", ephemeral=True)

        ranking = []
        for uid, data in pokedex.items():
            if data.get("capturas"):
                total = len(data["capturas"])
                especies = len(set(data["capturas"]))
                lendarios = sum(1 for p in data["capturas"] if any(pk['nome'] == p and pk['raridade'] == 'Lendario' for pk in POKEMON_DB))
                ranking.append({
                    'nome': data.get('nome', 'Desconhecido'),
                    'total': total,
                    'especies': especies,
                    'lendarios': lendarios
                })

        ranking.sort(key=lambda x: (-x['total'], -x['lendarios'], -x['especies']))

        if not ranking:
            return await interaction.response.send_message("📭 Ninguem capturou Pokemon ainda!", ephemeral=True)

        view = RankingView(ranking)
        view.update_buttons()
        await interaction.response.send_message(embed=view.get_current_embed(), view=view)

    @app_commands.command(name="trocar", description="Propor uma troca de Pokemon")
    @app_commands.describe(
        usuario="Usuario para trocar",
        oferecer="Pokemon que voce quer oferecer",
        pedir="Pokemon que voce quer receber"
    )
    @app_commands.autocomplete(oferecer=pokemon_autocomplete)
    async def slash_trocar(self, interaction: discord.Interaction, usuario: discord.Member, oferecer: str, pedir: str):
        if usuario.id == interaction.user.id:
            return await interaction.response.send_message("❌ Voce nao pode trocar consigo mesmo!", ephemeral=True)
        
        if usuario.bot:
            return await interaction.response.send_message("❌ Voce nao pode trocar com bots!", ephemeral=True)

        pokedex = JsonDatabase.load(Config.FILES['pokedex'], {})
        author_uid = str(interaction.user.id)
        target_uid = str(usuario.id)

        if author_uid not in pokedex or oferecer.title() not in pokedex[author_uid].get("capturas", []):
            return await interaction.response.send_message(f"❌ Voce nao tem **{oferecer}** para trocar!", ephemeral=True)

        if target_uid not in pokedex or pedir.title() not in pokedex[target_uid].get("capturas", []):
            return await interaction.response.send_message(f"❌ {usuario.display_name} nao tem **{pedir}** para trocar!", ephemeral=True)

        oferecer_info = get_pokemon_by_name(oferecer.title())
        pedir_info = get_pokemon_by_name(pedir.title())

        embed = discord.Embed(
            title="🔄 Proposta de Troca",
            description=f"{interaction.user.mention} quer trocar com {usuario.mention}!",
            color=discord.Color.blue()
        )
        embed.add_field(name=f"📤 {interaction.user.display_name} oferece", value=f"**{oferecer.title()}**", inline=True)
        embed.add_field(name=f"📥 {usuario.display_name} da", value=f"**{pedir.title()}**", inline=True)
        embed.set_footer(text="A troca expira em 2 minutos")

        view = TradeView(interaction.user, usuario, oferecer.title(), pedir.title())
        await interaction.response.send_message(content=usuario.mention, embed=embed, view=view)
        
        await view.wait()

        if view.accepted:
            pokedex = JsonDatabase.load(Config.FILES['pokedex'], {})
            
            if oferecer.title() not in pokedex[author_uid]["capturas"]:
                return await interaction.followup.send("❌ Troca cancelada: Pokemon nao disponivel!")
            if pedir.title() not in pokedex[target_uid]["capturas"]:
                return await interaction.followup.send("❌ Troca cancelada: Pokemon nao disponivel!")

            pokedex[author_uid]["capturas"].remove(oferecer.title())
            pokedex[target_uid]["capturas"].remove(pedir.title())
            pokedex[author_uid]["capturas"].append(pedir.title())
            pokedex[target_uid]["capturas"].append(oferecer.title())
            JsonDatabase.save(Config.FILES['pokedex'], pokedex)

            stats = self._load_stats()
            for uid in [author_uid, target_uid]:
                if uid not in stats:
                    stats[uid] = {"achievements": [], "battles_won": 0, "trades_completed": 0, "evolutions": 0}
                stats[uid]["trades_completed"] = stats[uid].get("trades_completed", 0) + 1
            self._save_stats(stats)

            self._grant_achievement(author_uid, "primeira_troca")
            self._grant_achievement(target_uid, "primeira_troca")

            embed = discord.Embed(
                title="✅ Troca Concluida!",
                description=f"{interaction.user.mention} e {usuario.mention} completaram a troca!",
                color=discord.Color.green()
            )
            embed.add_field(name=f"{interaction.user.display_name} recebeu", value=f"**{pedir.title()}**", inline=True)
            embed.add_field(name=f"{usuario.display_name} recebeu", value=f"**{oferecer.title()}**", inline=True)
            await interaction.followup.send(embed=embed)
        elif view.cancelled:
            await interaction.followup.send("❌ Troca cancelada!")
        else:
            await interaction.followup.send("⏰ Tempo esgotado! Troca cancelada.")

    @app_commands.command(name="batalhar", description="Desafiar alguem para uma batalha Pokemon")
    @app_commands.describe(
        oponente="Usuario para batalhar",
        pokemon="Seu Pokemon para a batalha"
    )
    @app_commands.autocomplete(pokemon=pokemon_autocomplete)
    async def slash_batalhar(self, interaction: discord.Interaction, oponente: discord.Member, pokemon: str):
        if oponente.id == interaction.user.id:
            return await interaction.response.send_message("❌ Voce nao pode batalhar consigo mesmo!", ephemeral=True)
        
        if oponente.bot:
            return await interaction.response.send_message("❌ Voce nao pode batalhar com bots!", ephemeral=True)

        pokedex = JsonDatabase.load(Config.FILES['pokedex'], {})
        challenger_uid = str(interaction.user.id)
        opponent_uid = str(oponente.id)

        if challenger_uid not in pokedex or pokemon.title() not in pokedex[challenger_uid].get("capturas", []):
            return await interaction.response.send_message(f"❌ Voce nao tem **{pokemon}**!", ephemeral=True)

        if opponent_uid not in pokedex or not pokedex[opponent_uid].get("capturas"):
            return await interaction.response.send_message(f"❌ {oponente.display_name} nao tem Pokemon!", ephemeral=True)

        challenger_poke = get_pokemon_by_name(pokemon.title())
        
        if not challenger_poke:
            return await interaction.response.send_message(f"❌ Pokemon **{pokemon}** nao encontrado!", ephemeral=True)
        
        embed = discord.Embed(
            title="⚔️ Desafio de Batalha!",
            description=f"{interaction.user.mention} desafia {oponente.mention} para uma batalha!\n\n**Pokemon:** {pokemon.title()}",
            color=discord.Color.red()
        )
        embed.set_thumbnail(url=get_pokemon_card_url(challenger_poke['id']))
        embed.set_footer(text="O desafiado tem 1 minuto para aceitar")

        view = BattleView(interaction.user, oponente)
        await interaction.response.send_message(content=oponente.mention, embed=embed, view=view)
        
        await view.wait()

        if view.accepted:
            opponent_capturas = pokedex[opponent_uid]["capturas"]
            opponent_poke_name = random.choice(opponent_capturas)
            opponent_poke = get_pokemon_by_name(opponent_poke_name)

            if not opponent_poke:
                await interaction.followup.send("❌ Erro ao carregar Pokemon do oponente!")
                return

            challenger_power = self._calculate_battle_power(challenger_poke, opponent_poke)
            opponent_power = self._calculate_battle_power(opponent_poke, challenger_poke)

            total = challenger_power + opponent_power
            challenger_chance = (challenger_power / total) * 100

            if random.randint(1, 100) <= challenger_chance:
                winner = interaction.user
                winner_poke = challenger_poke
                loser = oponente
                loser_poke = opponent_poke
                winner_uid = challenger_uid
            else:
                winner = oponente
                winner_poke = opponent_poke
                loser = interaction.user
                loser_poke = challenger_poke
                winner_uid = opponent_uid

            stats = self._load_stats()
            if winner_uid not in stats:
                stats[winner_uid] = {"achievements": [], "battles_won": 0, "trades_completed": 0, "evolutions": 0}
            stats[winner_uid]["battles_won"] = stats[winner_uid].get("battles_won", 0) + 1
            self._save_stats(stats)

            new_achs = []
            if stats[winner_uid]["battles_won"] >= 1:
                ach = self._grant_achievement(winner_uid, "primeira_batalha")
                if ach: new_achs.append(ach)
            if stats[winner_uid]["battles_won"] >= 10:
                ach = self._grant_achievement(winner_uid, "dez_batalhas")
                if ach: new_achs.append(ach)

            embed = discord.Embed(
                title="⚔️ Resultado da Batalha!",
                description=f"**{winner.display_name}** venceu com **{winner_poke['nome']}**!",
                color=discord.Color.gold()
            )
            embed.add_field(name=f"{interaction.user.display_name}", value=f"**{challenger_poke['nome']}** ({challenger_poke['tipo']})", inline=True)
            embed.add_field(name="VS", value="⚔️", inline=True)
            embed.add_field(name=f"{oponente.display_name}", value=f"**{opponent_poke['nome']}** ({opponent_poke['tipo']})", inline=True)
            embed.set_thumbnail(url=get_pokemon_card_url(winner_poke['id']))
            
            if new_achs:
                ach_text = "\n".join([f"{a['emoji']} **{a['nome']}** - {a['desc']}" for a in new_achs])
                embed.add_field(name="🎉 Nova Conquista!", value=ach_text, inline=False)

            await interaction.followup.send(embed=embed)
        elif view.cancelled:
            await interaction.followup.send("❌ Batalha cancelada!")
        else:
            await interaction.followup.send("⏰ Tempo esgotado! Batalha cancelada.")

    def _calculate_battle_power(self, attacker: dict, defender: dict) -> int:
        base_power = {'Comum': 10, 'Raro': 20, 'Epico': 35, 'Lendario': 50}
        power = base_power.get(attacker['raridade'], 10)

        attacker_types = attacker.get('tipo', 'Normal').split('/')
        defender_types = defender.get('tipo', 'Normal').split('/')

        for atk_type in attacker_types:
            for def_type in defender_types:
                if atk_type in TYPE_ADVANTAGES:
                    if def_type in TYPE_ADVANTAGES[atk_type].get('strong', []):
                        power *= 1.5
                    elif def_type in TYPE_ADVANTAGES[atk_type].get('weak', []):
                        power *= 0.75

        power *= random.uniform(0.85, 1.15)
        return int(power)

    @app_commands.command(name="conquistas", description="Ver suas conquistas Pokemon")
    @app_commands.describe(usuario="Usuario para ver conquistas (opcional)")
    async def slash_conquistas(self, interaction: discord.Interaction, usuario: Optional[discord.Member] = None):
        target = usuario or interaction.user
        uid = str(target.id)
        stats = self._load_stats()
        user_stats = stats.get(uid, {})
        achievements = user_stats.get("achievements", [])

        embed = discord.Embed(
            title=f"🏆 Conquistas de {target.display_name}",
            color=discord.Color.gold()
        )

        if not achievements:
            embed.description = "Nenhuma conquista ainda! Continue jogando!"
        else:
            earned = []
            for ach_id in achievements:
                ach = ACHIEVEMENTS.get(ach_id)
                if ach:
                    earned.append(f"{ach['emoji']} **{ach['nome']}** - {ach['desc']}")
            embed.description = "\n".join(earned)

        locked = []
        for ach_id, ach in ACHIEVEMENTS.items():
            if ach_id not in achievements:
                locked.append(f"🔒 ~~{ach['nome']}~~ - {ach['desc']}")
        
        if locked:
            embed.add_field(name="🔒 Bloqueadas", value="\n".join(locked[:10]), inline=False)

        embed.set_footer(text=f"{len(achievements)}/{len(ACHIEVEMENTS)} conquistas desbloqueadas")
        await interaction.response.send_message(embed=embed)

    @commands.command(name='pokemon')
    async def spawn_pokemon(self, ctx: commands.Context) -> None:
        if not self.check_cooldown(ctx.author.id, 'pokemon', 30):
            remaining = self.get_cooldown_remaining(ctx.author.id, 'pokemon', 30)
            await ctx.send(f"Aguarde {remaining}s para chamar outro Pokemon.")
            return

        chance = random.randint(1, 100)
        if chance <= 3:
            pool = get_pokemon_by_rarity('Lendario')
        elif chance <= 15:
            pool = get_pokemon_by_rarity('Epico')
        elif chance <= 40:
            pool = get_pokemon_by_rarity('Raro')
        else:
            pool = get_pokemon_by_rarity('Comum')

        poke = random.choice(pool)
        self.pokemon_atual = poke

        cor = RARITY_COLORS.get(poke['raridade'], 0x95a5a6)
        emoji = RARITY_EMOJIS.get(poke['raridade'], '')

        embed = discord.Embed(
            title=f"{emoji} Um {poke['nome']} selvagem apareceu!",
            description=f"**Raridade:** {poke['raridade']}\n**Tipo:** {poke.get('tipo', 'Normal')}\n\nUse `!pokebola` ou `/pokebola` para capturar!",
            color=cor
        )
        embed.set_image(url=get_pokemon_card_url(poke['id']))
        await ctx.send(embed=embed)

    @commands.command(name='pokebola')
    async def catch_pokemon(self, ctx: commands.Context) -> None:
        if not self.pokemon_atual:
            await ctx.send("Nenhum Pokemon para capturar! Use `!pokemon` primeiro.")
            return

        poke = self.pokemon_atual
        chances = {'Comum': 70, 'Raro': 50, 'Epico': 30, 'Lendario': 10}
        chance = chances.get(poke['raridade'], 50)

        if random.randint(1, 100) <= chance:
            pokedex = JsonDatabase.load(Config.FILES['pokedex'], {})
            uid = str(ctx.author.id)
            if uid not in pokedex:
                pokedex[uid] = {"nome": ctx.author.name, "capturas": []}
            pokedex[uid]["capturas"].append(poke['nome'])
            JsonDatabase.save(Config.FILES['pokedex'], pokedex)
            self.pokemon_atual = None

            embed = discord.Embed(
                title=f"GOTCHA! Voce capturou **{poke['nome']}**!",
                description=f"Use `!pokedex` para ver sua colecao!",
                color=discord.Color.gold()
            )
            embed.set_image(url=get_pokemon_card_url(poke['id']))
            await ctx.send(embed=embed)
        else:
            self.pokemon_atual = None
            await ctx.send(f"**{poke['nome']}** escapou da pokebola!")

    @commands.command(name='evoluir')
    async def evolve_pokemon(self, ctx: commands.Context, *, nome_poke: Optional[str] = None) -> None:
        if not self.check_cooldown(ctx.author.id, 'evoluir', 5):
            await ctx.send("Espere 5 segundos antes de evoluir outro Pokemon!")
            return
        
        if not nome_poke:
            await ctx.send("Use: `!evoluir [nome do pokemon]`")
            return

        uid = str(ctx.author.id)
        pokedex = JsonDatabase.load(Config.FILES['pokedex'], {})

        if uid not in pokedex or not pokedex[uid].get("capturas"):
            await ctx.send("Voce ainda nao tem Pokemon! Use `!pokemon` para comecar.")
            return

        nome_poke = nome_poke.title()
        info = get_pokemon_by_name(nome_poke)

        if not info:
            await ctx.send(f"Pokemon `{nome_poke}` nao encontrado.")
            return
        if not info['evolui_para']:
            await ctx.send(f"**{nome_poke}** ja esta no nivel maximo!")
            return

        qtd = pokedex[uid]['capturas'].count(info['nome'])
        if qtd < 3:
            await ctx.send(f"Voce precisa de 3 **{info['nome']}** para evoluir. Tem apenas {qtd}.")
            return

        for _ in range(3):
            pokedex[uid]['capturas'].remove(info['nome'])
        novo = info['evolui_para']
        pokedex[uid]['capturas'].append(novo)
        JsonDatabase.save(Config.FILES['pokedex'], pokedex)

        info_novo = get_pokemon_by_name(novo)
        embed = discord.Embed(
            title=f"Parabens! Seu {info['nome']} evoluiu para **{novo}**!",
            color=discord.Color.gold()
        )
        if info_novo:
            embed.set_image(url=get_pokemon_card_url(info_novo['id']))
        await ctx.send(content=f"{ctx.author.mention}", embed=embed)

    @commands.command(name='pokedex')
    async def show_pokedex(self, ctx: commands.Context, member: Optional[discord.Member] = None) -> None:
        target = member or ctx.author
        pokedex = JsonDatabase.load(Config.FILES['pokedex'], {})
        uid = str(target.id)

        if uid not in pokedex or not pokedex[uid].get("capturas"):
            if target == ctx.author:
                await ctx.send("Sua Pokedex esta vazia! Use `!pokemon` para comecar.")
            else:
                await ctx.send(f"A Pokedex de {target.display_name} esta vazia.")
            return

        lista = pokedex[uid]["capturas"]
        contagem = {}
        for pokemon in lista:
            contagem[pokemon] = contagem.get(pokemon, 0) + 1

        sorted_pokemon = sorted(contagem.items(), key=lambda x: (-x[1], x[0]))

        view = PokedexView(sorted_pokemon, target.display_name, target.id)
        await ctx.send(embed=view.get_current_embed(), view=view)

    @commands.command(name='ranking')
    async def pokemon_ranking(self, ctx: commands.Context) -> None:
        pokedex = JsonDatabase.load(Config.FILES['pokedex'], {})

        if not pokedex:
            return await ctx.send("Ninguem capturou Pokemon ainda!")

        ranking = []
        for uid, data in pokedex.items():
            if data.get("capturas"):
                total = len(data["capturas"])
                especies = len(set(data["capturas"]))
                lendarios = sum(1 for p in data["capturas"] if any(pk['nome'] == p and pk['raridade'] == 'Lendario' for pk in POKEMON_DB))
                ranking.append({
                    'nome': data.get('nome', 'Desconhecido'),
                    'total': total,
                    'especies': especies,
                    'lendarios': lendarios
                })

        ranking.sort(key=lambda x: (-x['total'], -x['lendarios'], -x['especies']))

        if not ranking:
            await ctx.send("Ninguem capturou Pokemon ainda!")
            return

        view = RankingView(ranking)
        view.update_buttons()
        await ctx.send(embed=view.get_current_embed(), view=view)


async def setup(bot):
    await bot.add_cog(PokemonCog(bot))
