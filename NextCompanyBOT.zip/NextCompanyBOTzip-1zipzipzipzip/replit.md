# NextCompany Discord Bot

## Overview

A Discord bot built for NextCompany that provides team management, productivity tracking, and entertainment features. The bot integrates with Desk.ms (a support ticketing system), includes a Pokemon collection game, manages work schedules with automated notifications, provides an AI-powered chat assistant using Google Gemini, and offers various team productivity tools.

**Core Features:**
- **Desk.ms Integration**: Real-time webhook notifications for support tickets with operator name resolution and API-based reporting
- **Pokemon Collection Game**: Capture, evolve, trade, and battle Pokemon with rarity-based mechanics and achievement system
- **Work Schedule Management**: Automated messages for work hours, lunch breaks, holidays, and custom reminders
- **AI Chat Assistant**: Context-aware chatbot using Google Gemini API with conversation and channel history
- **Web Search**: DuckDuckGo integration for search queries
- **Team Tools**: Raffle system, random selection tools, and support message generator

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Application Type
Discord bot application using discord.py 2.6.4+ with:
- Asynchronous HTTP server (aiohttp) for webhook endpoints
- Slash command support with autocomplete
- Cog-based modular architecture
- JSON file-based persistent storage

### Project Structure
```
├── main.py                      # Entry point, bot initialization
├── bot/
│   ├── workbot.py              # Main bot class, cog loader, session management
│   ├── config.py               # Environment configuration and constants
│   ├── constants.py            # Static messages and data
│   ├── cogs/                   # Feature modules (Discord cogs)
│   │   ├── pokemon.py          # Pokemon game system
│   │   ├── schedule.py         # Work schedule and reminders
│   │   ├── tools.py            # AI chat, search, utilities
│   │   ├── desk.py             # Desk.ms API integration
│   │   └── deskmanager.py      # Desk.ms webhook handler
│   ├── data/
│   │   └── pokemon.py          # Pokemon database (151 species)
│   └── utils/
│       ├── database.py         # JSON file operations
│       └── helpers.py          # Text formatting, time parsing
├── *.json                       # Persistent data files
```

### Command Architecture

**Hybrid Command Pattern**: All commands support both slash commands (`/command`) and traditional prefix commands (`!command`). The bot uses discord.py's `app_commands` for slash command registration with autocomplete support for complex inputs.

**Cog Organization**:
- **PokemonCog**: 10+ Pokemon-related commands (capture, evolve, battle, trade, pokedex)
- **ScheduleCog**: Work schedule automation and custom reminders
- **ToolsCog**: AI chat, web search, raffle, random selection
- **DeskCog**: Desk.ms API client for ticket reports
- **DeskManagerCog**: Webhook server for real-time ticket notifications

### Data Persistence Strategy

**JSON File-Based Storage**: The application uses local JSON files instead of a traditional database. This is a lightweight approach suitable for small-to-medium scale Discord bots.

**Key Data Files**:
- `pokedex.json`: User Pokemon collections (indexed by Discord user ID)
- `pokemon_stats.json`: User achievements, battle wins, trades, evolutions
- `chat_history.json`: Per-user conversation history with AI assistant
- `channel_history.json`: Channel-wide message history for context-aware responses
- `sorteo_history.json`: Raffle/lottery history
- `feriados.json`: Brazilian holiday definitions
- `config.json`: Dynamic configuration (work end times, etc.)

**Design Decision**: JSON files were chosen over PostgreSQL/MongoDB for:
- Simplicity: No database server setup required
- Portability: Easy to backup, migrate, and version control
- Scale: Sufficient for single Discord server usage
- Read/Write Pattern: Low-frequency writes, acceptable read performance

**Trade-offs**:
- **Pros**: Zero database maintenance, easy debugging, human-readable
- **Cons**: Not suitable for high concurrency, limited query capabilities, potential file locking issues

### AI Integration

**Google Gemini API**: Used for conversational AI assistant with custom personality tuning.

**Context Management**:
- **Per-user history**: Stores last N messages per user for personalized responses
- **Channel-wide history**: Maintains recent channel messages for context awareness (e.g., "Who is Rocky Balboa?" can reference earlier channel messages)
- **Custom personality**: Brazilian Portuguese informal tone, company-specific responses

**Implementation**: The `ToolsCog` maintains two separate history structures:
- `chat_history`: Dict[user_id, List[{pergunta, resposta}]]
- `channel_history`: Dict[channel_id, List[{usuario, pergunta, timestamp}]]

### External API Integrations

**Desk.ms Support Ticket System**:
- **Authentication**: Operator key + Environment key → JWT token (cached with expiration)
- **Webhook Endpoint**: POST /deskwebhook receives real-time ticket notifications
- **API Client**: GET requests for ticket reports with date filtering
- **Operator Resolution**: Caches operator ID-to-name mappings (1-hour TTL) with fallback dictionary

**Design Pattern**: The bot maintains dual integration:
1. **DeskManagerCog**: Passive webhook receiver (push notifications)
2. **DeskCog**: Active API client (pull requests for reports)

### Pokemon Game System

**Rarity-Based Mechanics**:
- 4 rarity tiers: Comum (60%), Raro (25%), Épico (10%), Lendário (5%)
- Evolution chains with rarity progression
- Type-based battle system with 18 Pokemon types and effectiveness multipliers

**Achievement System**: 12 unlockable achievements tracking milestones (first catch, 100 catches, all species, etc.)

**Battle Mechanics**:
- Turn-based combat with type advantages (e.g., Fire → Grass deals 1.5x damage)
- Random damage calculation with base stats
- Win tracking for achievement progression

**Trade System**: Player-to-player trading with proposal/accept flow using Discord UI buttons

### Webhook Server

**Embedded HTTP Server**: The bot runs an aiohttp web server alongside the Discord client for receiving webhooks.

**Endpoints**:
- `GET /`: Health check
- `POST /deskwebhook`: Desk.ms ticket notifications

**Design Decision**: Embedding the web server in the same process avoids complexity of separate services but requires the bot to be publicly accessible (via port forwarding or cloud deployment).

### Schedule Automation

**Time Zone**: All scheduling uses `America/Sao_Paulo` timezone (Brazilian time).

**Automated Messages**:
- Morning greeting (8:00 AM)
- Lunch start (12:00 PM)
- Lunch end (1:00 PM)
- End of day (configurable, default 6:00 PM)
- Weekend-specific messages

**Holiday Detection**: Checks `feriados.json` to skip automation on Brazilian holidays.

**Custom Reminders**: Users can set one-time or recurring reminders with natural language time parsing (e.g., "2h30m", "90m").

## External Dependencies

### Core Libraries
- **discord.py (2.6.4+)**: Discord API wrapper with slash commands, intents, and cog system
- **aiohttp (3.13.2+)**: Async HTTP client/server for API calls and webhook handling
- **certifi (2025.11.12+)**: SSL certificate verification for HTTPS requests

### AI & Search
- **google-generativeai (0.8.5+)**: Google Gemini API client for conversational AI
- **duckduckgo-search (8.1.1+)**: Web search functionality

### Utilities
- **python-dotenv (1.2.1+)**: Environment variable management
- **beautifulsoup4 (4.14.3+)**: HTML parsing (likely for Desk.ms webhook data)

### External Services
- **Desk.ms API**: Support ticket system (https://api.desk.ms)
  - Requires: `DESK_OPERATOR_KEY`, `DESK_ENVIRONMENT_KEY`
  - Authentication: JWT token-based
  - Used for: Ticket notifications, operator lookups, ticket reports
  
- **Google Gemini API**: Conversational AI
  - Requires: `GEMINI_KEY`
  - Used for: AI chat responses with custom personality

- **DuckDuckGo**: Web search (no API key required)

### Environment Variables
```
DISCORD_TOKEN          # Discord bot token (required)
GEMINI_KEY            # Google Gemini API key (optional, disables AI if missing)
DESK_OPERATOR_KEY     # Desk.ms operator authentication (optional)
DESK_ENVIRONMENT_KEY  # Desk.ms environment ID (optional)
DESK_API_URL          # Desk.ms API base URL (default: https://api.desk.ms)
DESK_CHANNEL_ID       # Discord channel for Desk notifications
DISCORD_CHANNEL_ID    # Main Discord channel for automated messages
DISCORD_ROLE_ID       # Role to mention in notifications
PORT                  # Webhook server port (default: 5000)
```

### Data Storage
- **JSON files**: All persistent data (no external database required)
- **File system**: Local file storage for JSON databases
- **In-memory caching**: Operator lookups (1-hour TTL), cooldowns, conversation history