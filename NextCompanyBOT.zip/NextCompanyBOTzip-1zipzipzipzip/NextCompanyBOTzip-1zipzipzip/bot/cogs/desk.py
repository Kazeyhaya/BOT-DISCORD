import discord
from discord.ext import commands
from discord import app_commands
import aiohttp
import ssl
import certifi
import logging
from typing import Optional, List, Dict, Any
from datetime import datetime, timedelta
import json
import re
from html import unescape

from ..config import Config

logger = logging.getLogger(__name__)


class DeskCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.base_url = Config.DESK_API_URL.rstrip('/')
        self.operator_key = Config.DESK_OPERATOR_KEY
        self.environment_key = Config.DESK_ENVIRONMENT_KEY
        self.token = None
        self.token_expires = None
        self._ssl_context = None
        self.operators_cache = {}  # Cache: {id: "Nome Sobrenome"}
        self.operators_cache_time = None
        
        if not self.operator_key or not self.environment_key:
            logger.warning("⚠️ Chaves Desk.ms não configuradas! Configure DESK_OPERATOR_KEY e DESK_ENVIRONMENT_KEY")
        else:
            logger.info("✅ Chaves Desk.ms carregadas com sucesso")
    
    def _get_ssl_context(self):
        if self._ssl_context is None:
            self._ssl_context = ssl.create_default_context(cafile=certifi.where())
        return self._ssl_context
    
    async def get_operators_cache(self) -> Dict[str, str]:
        """Busca e cacheia lista de operadores da API (cache 1 hora)"""
        now = datetime.now()
        
        # Retorna cache se válido (menos de 1 hora)
        if self.operators_cache and self.operators_cache_time and (now - self.operators_cache_time).total_seconds() < 3600:
            logger.debug(f"📋 Usando cache de operadores ({len(self.operators_cache)} operadores)")
            return self.operators_cache
        
        try:
            logger.info("📥 Buscando lista de operadores da API...")
            payload = {
                "Colunas": {
                    "Chave": "on",
                    "Nome": "on",
                    "Sobrenome": "on",
                    "Email": "on"
                },
                "Pesquisa": "",
                "Ativo": "S",
                "Filtro": {},
                "Ordem": [{"Coluna": "Nome", "Direcao": True}]
            }
            
            response = await self.api_request('POST', '/Operadores/lista', json=payload)
            
            if response and response.get('root'):
                cache = {}
                for op in response.get('root', []):
                    chave = str(op.get('Chave', ''))
                    nome = op.get('Nome', '')
                    sobrenome = op.get('Sobrenome', '')
                    nome_completo = f"{nome} {sobrenome}".strip()
                    
                    if chave and nome_completo:
                        cache[chave] = nome_completo
                
                self.operators_cache = cache
                self.operators_cache_time = now
                logger.info(f"✅ Cache atualizado: {len(cache)} operadores")
                return cache
            else:
                logger.warning("⚠️ Resposta vazia da API de operadores")
                return self.operators_cache or {}
        
        except Exception as e:
            logger.error(f"❌ Erro ao buscar operadores: {e}")
            return self.operators_cache or {}
    
    async def resolve_operator_name(self, operator_id: str) -> Optional[str]:
        """Resolve ID do operador para seu nome completo"""
        if not operator_id:
            return None
        
        # Buscar cache
        cache = await self.get_operators_cache()
        operator_id_str = str(operator_id).strip()
        
        if operator_id_str in cache:
            logger.debug(f"✅ Operador {operator_id_str} resolvido: {cache[operator_id_str]}")
            return cache[operator_id_str]
        
        logger.warning(f"⚠️ Operador {operator_id_str} não encontrado no cache")
        return None

    def _limpar_html(self, texto: str) -> str:
        """Remove tags HTML do texto"""
        if not texto:
            return ""
        # Remove tags HTML
        texto = re.sub(r'<[^>]+>', '', texto)
        # Decodifica entidades HTML
        texto = unescape(texto)
        # Remove espaços múltiplos
        texto = re.sub(r'\s+', ' ', texto).strip()
        return texto

    def _get_periodo_info(self, periodo: Optional[str] = None) -> tuple:
        """Retorna intervalo de datas para o período solicitado (baseado em datas calendário)
        Retorna: (data_inicio, data_fim, descricao_periodo)
        """
        from zoneinfo import ZoneInfo
        now = datetime.now(ZoneInfo("America/Sao_Paulo"))
        
        if not periodo:
            periodo = "semestre"
        
        periodo_lower = periodo.lower().strip()
        
        if periodo_lower in ["semestre", "últimosemestre", "ultimo_semestre", "6m"]:
            # Segundo semestre (jul-dez) ou primeiro semestre (jan-jun)
            if now.month >= 7:
                data_inicio = now.replace(month=7, day=1, hour=0, minute=0, second=0, microsecond=0)
                descricao = "2º Semestre 2025"
            else:
                data_inicio = now.replace(month=1, day=1, hour=0, minute=0, second=0, microsecond=0)
                descricao = "1º Semestre 2025"
        elif periodo_lower in ["trimestre", "últimotrimestre", "ultimo_trimestre", "3m"]:
            # Trimestres: Q1(1-3), Q2(4-6), Q3(7-9), Q4(10-12)
            trimestre = (now.month - 1) // 3 + 1
            mes_inicio = (trimestre - 1) * 3 + 1
            data_inicio = now.replace(month=mes_inicio, day=1, hour=0, minute=0, second=0, microsecond=0)
            descricao = f"Q{trimestre} 2025"
        elif periodo_lower in ["mês", "mes", "meses", "últimomês", "ultimo_mes", "1m"]:
            # Mês atual do dia 1 até hoje
            data_inicio = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
            descricao = now.strftime("Mês atual (%B)")
        elif periodo_lower in ["semana", "últimasemana", "ultima_semana", "7d"]:
            # Última semana (últimos 7 dias exatos)
            data_inicio = now - timedelta(days=7)
            descricao = "Últimos 7 dias"
        elif periodo_lower in ["hoje", "today", "1d"]:
            # Apenas hoje
            data_inicio = now.replace(hour=0, minute=0, second=0, microsecond=0)
            descricao = "Hoje"
        else:
            # Padrão: semestre atual
            if now.month >= 7:
                data_inicio = now.replace(month=7, day=1, hour=0, minute=0, second=0, microsecond=0)
                descricao = "2º Semestre 2025"
            else:
                data_inicio = now.replace(month=1, day=1, hour=0, minute=0, second=0, microsecond=0)
                descricao = "1º Semestre 2025"
        
        # Formatar datas para a API (DD/MM/YYYY)
        data_inicio_str = data_inicio.strftime("%d/%m/%Y")
        data_fim_str = now.strftime("%d/%m/%Y")
        
        return data_inicio_str, data_fim_str, descricao

    async def get_auth_token(self, retry_count: int = 0) -> Optional[str]:
        """Obter token de autenticação da API Desk (com cache e retry)"""
        if self.token and self.token_expires and datetime.now() < self.token_expires:
            logger.debug("🔑 Usando token em cache")
            return self.token
        
        if not self.operator_key or not self.environment_key:
            logger.error("❌ Chaves de API não configuradas")
            return None
        
        max_retries = 3
        
        try:
            url = f"{self.base_url}/Login/autenticar"
            
            headers = {
                "Authorization": self.operator_key,
                "Content-Type": "application/json",
                "Accept": "application/json"
            }
            payload = {"PublicKey": self.environment_key}
            
            logger.info(f"🔑 Autenticando na API Desk: {url}")
            logger.debug(f"Headers: Authorization=***{self.operator_key[-8:] if self.operator_key else 'N/A'}")
            
            timeout = aiohttp.ClientTimeout(total=30, connect=10)
            ssl_context = self._get_ssl_context()
            
            async with self.bot.session.post(
                url, 
                json=payload, 
                headers=headers, 
                timeout=timeout,
                ssl=ssl_context
            ) as resp:
                content_type = resp.headers.get('Content-Type', '')
                text = await resp.text()
                
                logger.debug(f"Status: {resp.status}, Content-Type: {content_type}")
                logger.debug(f"Resposta (primeiros 200 chars): {text[:200]}")
                
                if resp.status == 200:
                    token = None
                    
                    if 'application/json' in content_type:
                        try:
                            data = json.loads(text)
                            if isinstance(data, dict):
                                token = data.get('access_token') or data.get('token') or data.get('accessToken')
                                if data.get('erro'):
                                    logger.error(f"❌ API retornou erro: {data.get('erro')}")
                                    return None
                            elif isinstance(data, str):
                                token = data
                        except json.JSONDecodeError:
                            text_clean = text.strip().strip('"')
                            if text_clean and not text_clean.startswith('<') and len(text_clean) > 20:
                                token = text_clean
                    else:
                        text_clean = text.strip().strip('"')
                        if text_clean and not text_clean.startswith('<') and len(text_clean) > 20:
                            token = text_clean
                    
                    if token:
                        self.token = token
                        self.token_expires = datetime.now() + timedelta(hours=1)
                        logger.info(f"✅ Token obtido com sucesso! Válido por 1 hora")
                        logger.debug(f"Token: {self.token[:20]}...{self.token[-8:]}")
                        return self.token
                    else:
                        logger.error(f"❌ Token não encontrado na resposta")
                        logger.error(f"Content-Type: {content_type}")
                        logger.error(f"Resposta: {text[:300]}")
                        return None
                else:
                    logger.error(f"❌ Erro ao autenticar: HTTP {resp.status}")
                    logger.error(f"Content-Type: {content_type}")
                    logger.error(f"Resposta: {text[:300]}")
                    
                    if resp.status in [500, 502, 503, 504] and retry_count < max_retries:
                        logger.warning(f"⚠️ Tentando novamente... ({retry_count + 1}/{max_retries})")
                        import asyncio
                        await asyncio.sleep(2 ** retry_count)
                        return await self.get_auth_token(retry_count + 1)
                    
                    return None
                    
        except aiohttp.ClientSSLError as e:
            logger.error(f"❌ Erro SSL na conexão: {e}")
            if retry_count < max_retries:
                logger.warning(f"⚠️ Tentando novamente com SSL... ({retry_count + 1}/{max_retries})")
                import asyncio
                await asyncio.sleep(2 ** retry_count)
                return await self.get_auth_token(retry_count + 1)
            return None
        except aiohttp.ClientConnectorError as e:
            logger.error(f"❌ Erro de conexão com API Desk: {e}")
            if retry_count < max_retries:
                logger.warning(f"⚠️ Tentando reconectar... ({retry_count + 1}/{max_retries})")
                import asyncio
                await asyncio.sleep(2 ** retry_count)
                return await self.get_auth_token(retry_count + 1)
            return None
        except aiohttp.ClientError as e:
            logger.error(f"❌ Erro de cliente HTTP: {e}")
            return None
        except Exception as e:
            logger.error(f"❌ Erro inesperado ao obter token: {type(e).__name__}: {e}")
            return None

    async def api_request(self, method: str, endpoint: str, retry_count: int = 0, **kwargs) -> Optional[Dict[str, Any]]:
        """Fazer requisição à API do Desk com retry"""
        token = await self.get_auth_token()
        if not token:
            logger.error("❌ Não foi possível obter token de autenticação")
            return None
        
        max_retries = 3
        
        try:
            url = f"{self.base_url}/{endpoint.lstrip('/')}"
            headers = {
                "Authorization": token,
                "Content-Type": "application/json",
                "Accept": "application/json"
            }
            
            logger.info(f"🔗 Requisição API: {method} {url}")
            
            if 'json' in kwargs:
                logger.info(f"📤 Payload: {json.dumps(kwargs['json'], ensure_ascii=False)}")
            
            timeout = aiohttp.ClientTimeout(total=30, connect=10)
            ssl_context = self._get_ssl_context()
            
            async with self.bot.session.request(
                method, 
                url, 
                headers=headers, 
                timeout=timeout, 
                ssl=ssl_context,
                **kwargs
            ) as resp:
                text = await resp.text()
                
                if resp.status == 401:
                    logger.warning("⚠️ Token expirado ou inválido, tentando renovar...")
                    self.token = None
                    self.token_expires = None
                    if retry_count < 1:
                        return await self.api_request(method, endpoint, retry_count + 1, **kwargs)
                    return None
                
                if resp.status in [500, 502, 503, 504] and retry_count < max_retries:
                    logger.warning(f"⚠️ Servidor indisponível, tentando novamente... ({retry_count + 1}/{max_retries})")
                    import asyncio
                    await asyncio.sleep(2 ** retry_count)
                    return await self.api_request(method, endpoint, retry_count + 1, **kwargs)
                
                try:
                    data = json.loads(text)
                    if isinstance(data, dict):
                        if data.get('erro'):
                            logger.warning(f"⚠️ API retornou erro: {data.get('erro')}")
                        total = data.get('total', 'N/A')
                        root_count = len(data.get('root', [])) if isinstance(data.get('root'), list) else 0
                        logger.info(f"📥 Resposta: total={total}, root_count={root_count}")
                        if root_count > 0:
                            sample = data['root'][0]
                            logger.info(f"📋 Campos: {list(sample.keys())}")
                    return data
                except json.JSONDecodeError:
                    if '<html' in text.lower():
                        logger.error(f"❌ API retornou HTML em vez de JSON")
                        self.token = None
                        self.token_expires = None
                    else:
                        logger.error(f"❌ Erro ao parsear resposta: {text[:200]}")
                    return None
                    
        except aiohttp.ClientConnectorError as e:
            logger.error(f"❌ Erro de conexão: {e}")
            if retry_count < max_retries:
                logger.warning(f"⚠️ Tentando reconectar... ({retry_count + 1}/{max_retries})")
                import asyncio
                await asyncio.sleep(2 ** retry_count)
                return await self.api_request(method, endpoint, retry_count + 1, **kwargs)
            return None
        except aiohttp.ClientError as e:
            logger.error(f"❌ Erro de conexão: {e}")
            return None
        except Exception as e:
            logger.error(f"❌ Erro na requisição API: {type(e).__name__}: {e}")
            return None

    @commands.command(name='desk-status')
    async def desk_status(self, ctx: commands.Context) -> None:
        """Verificar status da conexão com Desk.ms"""
        async with ctx.typing():
            embed = discord.Embed(
                title="🔍 Status da Conexão Desk.ms",
                color=discord.Color.blue()
            )
            
            has_keys = bool(self.operator_key and self.environment_key)
            embed.add_field(
                name="Chaves Configuradas",
                value="✅ Sim" if has_keys else "❌ Não",
                inline=True
            )
            
            if has_keys:
                token = await self.get_auth_token()
                if token:
                    embed.add_field(name="Autenticação", value="✅ OK", inline=True)
                    embed.add_field(
                        name="Token Expira",
                        value=self.token_expires.strftime("%H:%M:%S") if self.token_expires else "N/A",
                        inline=True
                    )
                    embed.color = discord.Color.green()
                    
                    payload = {"Pesquisa": "", "Ordem": [{"Coluna": "DataCriacao", "Direcao": "false"}]}
                    response = await self.api_request('POST', '/ChamadosSuporte/lista', json=payload)
                    if response:
                        total = response.get('total', 0)
                        root_count = len(response.get('root', []))
                        embed.add_field(name="Tickets Disponíveis", value=f"{total} (retornou {root_count})", inline=True)
                        if root_count > 0:
                            sample = response['root'][0]
                            cod = sample.get('CodChamado', 'N/A')
                            embed.add_field(name="Exemplo de ID", value=cod, inline=True)
                    else:
                        embed.add_field(name="Tickets", value="❌ Erro na consulta", inline=True)
                else:
                    embed.add_field(name="Autenticação", value="❌ Falhou", inline=True)
                    embed.color = discord.Color.red()
            
            embed.add_field(name="API URL", value=self.base_url, inline=False)
            await ctx.send(embed=embed)

    @commands.command(name='ticket')
    async def consultar_ticket(self, ctx: commands.Context, ticket_id: str) -> None:
        """Consultar informações de um ticket"""
        async with ctx.typing():
            logger.info(f"🔍 Buscando ticket: {ticket_id}")
            
            payload = {
                "Pesquisa": ticket_id,
                "Ordem": [{"Coluna": "DataCriacao", "Direcao": "false"}]
            }
            response = await self.api_request('POST', '/ChamadosSuporte/lista', json=payload)
            
            if not response:
                await ctx.send(f"❌ Erro ao conectar com a API")
                return
            
            if response.get('erro'):
                await ctx.send(f"❌ Erro da API: {response.get('erro')}")
                return
            
            tickets = response.get('root', [])
            total = response.get('total', 0)
            logger.info(f"📋 Resposta com pesquisa '{ticket_id}': {total} ticket(s)")
            
            if not tickets:
                payload_all = {
                    "Pesquisa": "",
                    "Ordem": [{"Coluna": "DataCriacao", "Direcao": "false"}]
                }
                response_all = await self.api_request('POST', '/ChamadosSuporte/lista', json=payload_all)
                if response_all and response_all.get('root'):
                    tickets = response_all.get('root', [])
                    total = response_all.get('total', 0)
                    logger.info(f"📋 Buscando em todos os {total} tickets...")
            
            if tickets and len(tickets) > 0:
                sample = tickets[0]
                logger.info(f"🔑 Campos do ticket: {list(sample.keys())}")
                logger.info(f"📝 CodChamado exemplo: {sample.get('CodChamado')}")
            
            data = None
            ticket_id_clean = ticket_id.replace('-', '').lower().strip()
            ticket_id_numbers = ''.join(filter(str.isdigit, ticket_id))
            
            for ticket in tickets:
                cod = str(ticket.get('CodChamado', '')).lower()
                chave = str(ticket.get('Chave', '')).lower()
                cod_clean = cod.replace('-', '')
                chave_clean = chave.replace('-', '')
                cod_numbers = ''.join(filter(str.isdigit, cod))
                
                if ticket_id_clean == cod_clean or ticket_id_clean == chave_clean:
                    data = ticket
                    logger.info(f"✅ Match exato: {cod}")
                    break
                if ticket_id_clean in cod_clean or ticket_id_clean in chave_clean:
                    data = ticket
                    logger.info(f"✅ Match parcial: {cod}")
                    break
                if ticket_id_numbers and ticket_id_numbers in cod_numbers:
                    data = ticket
                    logger.info(f"✅ Match numérico: {cod}")
                    break
            
            if not data:
                await ctx.send(f"❌ Ticket `{ticket_id}` não encontrado")
                return
            
            assunto = data.get('Assunto', 'Sem assunto')
            nome_status = data.get('NomeStatus', '')
            if isinstance(nome_status, list) and nome_status:
                status = nome_status[0].get('text', 'Desconhecido')
            elif isinstance(nome_status, str) and nome_status:
                status = nome_status
            else:
                status = 'Desconhecido'
            
            nome_usuario = data.get('NomeUsuario', '')
            sobrenome_usuario = data.get('SobrenomeUsuario', '')
            cliente = f"{nome_usuario} {sobrenome_usuario}".strip() or 'Não informado'
            
            prioridade = data.get('NomePrioridade', '---')
            
            nome_operador = data.get('NomeOperador', '')
            sobrenome_operador = data.get('SobrenomeOperador', '')
            analista = f"{nome_operador} {sobrenome_operador}".strip() or 'Não atribuído'
            
            descricao = data.get('Descricao', '')[:200]
            data_criacao = data.get('DataCriacao', '---')
            
            status_lower = status.lower()
            if any(x in status_lower for x in ['resolvido', 'finalizado', 'encerrado']):
                emoji, cor = "✅", discord.Color.green()
            elif any(x in status_lower for x in ['cancelado', 'rejeitado']):
                emoji, cor = "❌", discord.Color.red()
            elif any(x in status_lower for x in ['andamento', 'atendimento']):
                emoji, cor = "🔧", discord.Color.orange()
            else:
                emoji, cor = "🆕", discord.Color.blue()
            
            embed = discord.Embed(
                title=f"Ticket #{ticket_id}",
                description=f"{emoji} **{assunto}**",
                color=cor
            )
            embed.add_field(name="Status", value=status, inline=True)
            embed.add_field(name="Prioridade", value=prioridade, inline=True)
            embed.add_field(name="Cliente", value=cliente, inline=False)
            embed.add_field(name="Analista", value=analista, inline=True)
            embed.add_field(name="Criado em", value=data_criacao, inline=True)
            if descricao:
                embed.add_field(name="Descrição", value=descricao, inline=False)
            
            embed.set_footer(text="Desk.ms Integration")
            await ctx.send(embed=embed)

    @commands.command(name='tickets-fechados')
    async def listar_tickets_fechados(self, ctx: commands.Context) -> None:
        """Listar últimos tickets fechados do sistema"""
        async with ctx.typing():
            payload = {
                "Pesquisa": "",
                "Ordem": [{"Coluna": "DataCriacao", "Direcao": "false"}]
            }
            response = await self.api_request('POST', '/ChamadosSuporte/lista', json=payload)
            
            if not response or response.get('erro'):
                erro = response.get('erro') if response else "Nenhum ticket encontrado"
                await ctx.send(f"📋 {erro}")
                return
            
            tickets_fechados = []
            for ticket in response.get('root', []):
                nome_status = ticket.get('NomeStatus', [])
                if isinstance(nome_status, list) and nome_status:
                    status_text = nome_status[0].get('text', '').lower()
                    if any(x in status_text for x in ['resolvido', 'finalizado', 'encerrado', 'fechado']):
                        tickets_fechados.append(ticket)
                        if len(tickets_fechados) >= 10:
                            break
            
            if not tickets_fechados:
                await ctx.send("📋 Nenhum ticket fechado encontrado.")
                return
            
            embed = discord.Embed(
                title=f"✅ Últimos Tickets Fechados ({len(tickets_fechados)})",
                color=discord.Color.green()
            )
            
            for ticket in tickets_fechados:
                id_ticket = str(ticket.get('CodChamado', 'N/A'))
                assunto = ticket.get('Assunto', 'Sem assunto')[:50]
                nome_status = ticket.get('NomeStatus', [])
                status = nome_status[0].get('text', '---') if isinstance(nome_status, list) and nome_status else '---'
                prioridade = ticket.get('NomePrioridade', '---')
                
                embed.add_field(
                    name=f"#{id_ticket} - {assunto}",
                    value=f"**Status:** {status} | **Prioridade:** {prioridade}",
                    inline=False
                )
            
            embed.set_footer(text="Use !ticket [ID] para mais detalhes")
            await ctx.send(embed=embed)

    @commands.command(name='tickets')
    async def pesquisar_tickets_usuario(self, ctx: commands.Context, *, filtro: Optional[str] = None) -> None:
        """Listar tickets em aberto (ou filtrar por status)
        
        Uso:
        - `!tickets` - Seus tickets em aberto
        - `!tickets [status]` - Tickets com esse status (ex: resolvido, andamento)
        """
        async with ctx.typing():
            payload = {
                "Pesquisa": "",
                "Ordem": [{"Coluna": "DataCriacao", "Direcao": "false"}]
            }
            response = await self.api_request('POST', '/ChamadosSuporte/lista', json=payload)
            
            if not response or response.get('erro'):
                erro = response.get('erro') if response else "Nenhum ticket encontrado"
                await ctx.send(f"📋 {erro}")
                return
            
            todos_tickets = response.get('root', [])
            
            if not todos_tickets:
                await ctx.send("📋 Nenhum ticket encontrado.")
                return
            
            # Se houver filtro de status, aplicar
            if filtro:
                filtro_lower = filtro.lower()
                tickets_filtrados = []
                for ticket in todos_tickets:
                    nome_status = ticket.get('NomeStatus', [])
                    if isinstance(nome_status, list) and nome_status:
                        status_text = nome_status[0].get('text', '').lower()
                    else:
                        status_text = str(nome_status).lower() if nome_status else ''
                    
                    if filtro_lower in status_text:
                        tickets_filtrados.append(ticket)
                
                if not tickets_filtrados:
                    await ctx.send(f"📋 Nenhum ticket encontrado com status `{filtro}`")
                    return
                
                # Pegar os 25 mais recentes
                tickets_final = tickets_filtrados[:25]
                titulo = f"🔍 Tickets com Status '{filtro}' ({len(tickets_final)})"
            else:
                # Filtrar apenas tickets ABERTOS (excluir fechados/resolvidos)
                tickets_abertos = []
                for ticket in todos_tickets:
                    nome_status = ticket.get('NomeStatus', [])
                    if isinstance(nome_status, list) and nome_status:
                        status_text = nome_status[0].get('text', '').lower()
                    else:
                        status_text = str(nome_status).lower() if nome_status else ''
                    
                    # Excluir tickets fechados/resolvidos/cancelados
                    if not any(x in status_text for x in ['resolvido', 'finalizado', 'encerrado', 'fechado', 'cancelado', 'rejeitado']):
                        tickets_abertos.append(ticket)
                
                if not tickets_abertos:
                    await ctx.send("✅ Nenhum ticket em aberto! Parabéns!")
                    return
                
                # Pegar os 25 mais recentes
                tickets_final = tickets_abertos[:25]
                titulo = f"🆕 Tickets em Aberto ({len(tickets_final)})"
            
            embed = discord.Embed(
                title=titulo,
                color=discord.Color.blue()
            )
            
            for ticket in tickets_final:
                id_ticket = str(ticket.get('CodChamado', 'N/A'))
                assunto = ticket.get('Assunto', 'Sem assunto')[:50]
                nome_status = ticket.get('NomeStatus', [])
                status = nome_status[0].get('text', '---') if isinstance(nome_status, list) and nome_status else '---'
                prioridade = ticket.get('NomePrioridade', '---')
                
                embed.add_field(
                    name=f"#{id_ticket} - {assunto}",
                    value=f"**Status:** {status} | **Prioridade:** {prioridade}",
                    inline=False
                )
            
            embed.set_footer(text="Use !ticket [ID] para mais detalhes")
            await ctx.send(embed=embed)

    @commands.command(name='abrir-ticket')
    async def abrir_ticket(self, ctx: commands.Context, *, assunto: str) -> None:
        """Abrir um novo ticket"""
        if len(assunto) > 200:
            await ctx.send("❌ O assunto não pode ter mais de 200 caracteres.")
            return
        
        async with ctx.typing():
            payload = {
                "assunto": assunto,
                "usuario_nome": ctx.author.display_name,
                "descr": f"Aberto via Discord por {ctx.author.display_name}"
            }
            
            result = await self.api_request('POST', '/Chamados', json=payload)
            
            if not result or result.get('erro'):
                erro = result.get('erro') if result else "Erro ao criar ticket"
                await ctx.send(f"❌ {erro}")
                return
            
            ticket_id = result.get('chamado_cod', result.get('id', 'N/A'))
            embed = discord.Embed(
                title="✅ Ticket Criado com Sucesso!",
                description=f"**ID do Ticket:** #{ticket_id}",
                color=discord.Color.green()
            )
            embed.add_field(name="Assunto", value=assunto, inline=False)
            embed.add_field(name="Próximo Passo", value="Use `!ticket " + str(ticket_id) + "` para acompanhar", inline=False)
            await ctx.send(embed=embed)

    @commands.command(name='kb-search')
    async def pesquisar_base_conhecimento(self, ctx: commands.Context, *, termo: str) -> None:
        """Pesquisar na base de conhecimento"""
        async with ctx.typing():
            logger.info(f"🔍 Pesquisando base de conhecimento: {termo}")
            
            payload = {
                "Pesquisa": termo,
                "Ordem": [{"Coluna": "Titulo", "Direcao": "true"}]
            }
            response = await self.api_request('POST', '/BaseConhecimento/lista', json=payload)
            
            if not response:
                await ctx.send("❌ Erro ao conectar com a base de conhecimento")
                return
            
            if response.get('erro'):
                await ctx.send(f"❌ Erro: {response.get('erro')}")
                return
            
            artigos = response.get('root', [])
            total = response.get('total', 0)
            logger.info(f"📚 Encontrados {total} artigos para '{termo}'")
            
            if not artigos:
                await ctx.send(f"❌ Nenhum artigo encontrado para '{termo}'")
                return
            
            embed = discord.Embed(
                title=f"📚 Base de Conhecimento - Resultados",
                description=f"Pesquisa: `{termo}`\nEncontrados: {total} artigos",
                color=discord.Color.blue()
            )
            
            for artigo in artigos[:10]:
                chave = artigo.get('Chave', 'N/A')
                titulo = artigo.get('Titulo', 'Sem título')
                categorias = artigo.get('Categoria', [])
                categoria_text = categorias[0].get('text', '---') if categorias else '---'
                palavras_chave = artigo.get('PalavrasChave', '')
                
                valor = f"**Categoria:** {categoria_text}\n"
                if palavras_chave:
                    valor += f"**Tags:** {palavras_chave}"
                
                embed.add_field(
                    name=f"#{chave} - {titulo[:50]}",
                    value=valor,
                    inline=False
                )
            
            embed.set_footer(text=f"Use !kb-artigo [ID] para mais detalhes | Total: {total} artigos")
            await ctx.send(embed=embed)

    @commands.command(name='kb-artigo')
    async def ver_artigo_conhecimento(self, ctx: commands.Context, chave: str) -> None:
        """Ver artigo específico da base de conhecimento"""
        async with ctx.typing():
            # Limpar a chave removendo # e espaços
            chave_limpa = chave.replace('#', '').strip()
            logger.info(f"📖 Consultando artigo KB: {chave} (limpa: {chave_limpa})")
            
            payload = {"Chave": chave_limpa}
            response = await self.api_request('POST', '/BaseConhecimento', json=payload)
            
            if not response:
                await ctx.send("❌ Erro ao conectar com a base de conhecimento")
                return
            
            logger.debug(f"📝 Resposta completa: {response}")
            artigo = response.get('TBaseConhecimento')
            if not artigo:
                logger.warning(f"⚠️ Artigo {chave_limpa} não encontrado. Response keys: {list(response.keys())}")
                await ctx.send(f"❌ Artigo #{chave_limpa} não encontrado")
                return
            
            titulo = artigo.get('Titulo', 'Sem título')
            categorias = artigo.get('Categoria', [])
            categoria_text = categorias[0].get('text', '---') if categorias else '---'
            palavras_chave = artigo.get('PalavrasChave', '')
            conteudo = artigo.get('Conteudo', '') or artigo.get('Comentarios', '')
            link_externo = artigo.get('LinkExterno', '')
            link_direto = artigo.get('LinkDireto', '')
            aprovador = artigo.get('Aprovador', 'N/A')
            publico = artigo.get('Publico', 'N') == 'S'
            visivel_operadores = artigo.get('VisivelTodosOperadores', 'N') == 'S'
            visivel_usuarios = artigo.get('VisivelTodosUsuarios', 'N') == 'S'
            cat_adicionais = artigo.get('CatAdicionais', '')
            
            embed = discord.Embed(
                title=f"📖 {titulo}",
                color=discord.Color.blurple()
            )
            
            embed.add_field(name="ID", value=f"#{chave}", inline=True)
            embed.add_field(name="Categoria", value=categoria_text, inline=True)
            
            # Mostrar categorias adicionais se existirem
            if cat_adicionais:
                embed.add_field(name="Categorias Adicionais", value=cat_adicionais, inline=True)
            
            # Permissões
            perms = []
            if publico:
                perms.append("🌐 Pública")
            if visivel_operadores:
                perms.append("👨‍💼 Todos Operadores")
            if visivel_usuarios:
                perms.append("👥 Todos Usuários")
            if perms:
                embed.add_field(name="Visibilidade", value=" | ".join(perms), inline=False)
            
            # Restrições de acesso
            cod_clientes = artigo.get('CodCliente', [])
            cod_depts = artigo.get('CodDepartamento', [])
            cod_grupos = artigo.get('CodGrupo', [])
            
            if cod_clientes:
                clientes_text = ", ".join([c.get('text', '') for c in cod_clientes[:3]])
                if len(cod_clientes) > 3:
                    clientes_text += f" +{len(cod_clientes)-3}"
                embed.add_field(name="Clientes Autorizados", value=clientes_text, inline=True)
            
            if cod_depts:
                depts_text = ", ".join([d.get('text', '') for d in cod_depts[:2]])
                if len(cod_depts) > 2:
                    depts_text += f" +{len(cod_depts)-2}"
                embed.add_field(name="Departamentos", value=depts_text, inline=True)
            
            if cod_grupos:
                grupos_text = ", ".join([g.get('text', '') for g in cod_grupos[:2]])
                if len(cod_grupos) > 2:
                    grupos_text += f" +{len(cod_grupos)-2}"
                embed.add_field(name="Grupos de Atendimento", value=grupos_text, inline=True)
            
            if palavras_chave:
                embed.add_field(name="Tags", value=palavras_chave, inline=False)
            
            if conteudo:
                conteudo_limpo = self._limpar_html(conteudo)
                conteudo_truncado = conteudo_limpo[:500] + "..." if len(conteudo_limpo) > 500 else conteudo_limpo
                embed.add_field(name="Conteúdo", value=conteudo_truncado, inline=False)
            
            # Links na parte final
            links_text = ""
            if link_direto:
                links_text += f"🔗 [Visualizar Artigo]({link_direto})\n"
            if link_externo:
                links_text += f"🌐 [Link Externo]({link_externo})"
            
            if links_text:
                embed.add_field(name="📌 Acesso Rápido", value=links_text, inline=False)
            
            embed.set_footer(text="Desk.ms Knowledge Base")
            await ctx.send(embed=embed)

    async def _buscar_relatorio_slideshow(self, data_inicio: str, data_fim: str) -> Dict:
        """Busca dados de relatório via endpoint SlideShow (sem limite de 3000)"""
        try:
            data_inicio_obj = datetime.strptime(data_inicio, "%d/%m/%Y")
            data_fim_obj = datetime.strptime(data_fim, "%d/%m/%Y")
            logger.info(f"📅 Tentando SlideShow com período: {data_inicio} a {data_fim}")
        except Exception as e:
            logger.error(f"❌ Erro ao parsear datas: {e}")
            return {}
        
        # Tentar endpoint SlideShow com diferentes chaves
        for chave in ["Chamados", "chamados", ""]:
            try:
                payload = {"Chave": chave}
                logger.info(f"🔍 SlideShow com Chave='{chave}'...")
                response = await self.api_request('POST', '/SlideShow', json=payload)
                
                if response and not response.get('erro'):
                    logger.info(f"✅ SlideShow {chave} disponível!")
                    return response.get('rSlideShow', response)
            except Exception as e:
                logger.debug(f"⚠️ SlideShow falhou com Chave='{chave}': {e}")
        
        logger.warning(f"⚠️ SlideShow não funcionou, usando ChamadosSuporte/lista")
        return {}
    
    def _parse_date_flexible(self, data_str: str) -> Optional[datetime]:
        """Parse de data flexível que suporta múltiplos formatos do Desk.ms"""
        if not data_str or not isinstance(data_str, str):
            return None
        
        data_str = data_str.strip()
        
        formatos = [
            "%d/%m/%Y %H:%M:%S",
            "%d/%m/%Y %H:%M",
            "%d/%m/%Y",
            "%Y-%m-%d %H:%M:%S",
            "%Y-%m-%d %H:%M",
            "%Y-%m-%d",
            "%Y-%m-%dT%H:%M:%S",
            "%Y-%m-%dT%H:%M:%SZ",
            "%Y-%m-%dT%H:%M:%S.%f",
            "%Y-%m-%dT%H:%M:%S.%fZ",
        ]
        
        for formato in formatos:
            try:
                return datetime.strptime(data_str[:len(formato.replace('%', '').replace('d', 'X').replace('m', 'X').replace('Y', 'XXXX').replace('H', 'X').replace('M', 'X').replace('S', 'X').replace('f', 'XXXXXX').replace('T', 'X').replace('Z', 'X').replace('-', 'X').replace('/', 'X').replace(':', 'X').replace('.', 'X').replace(' ', 'X'))], formato)
            except (ValueError, IndexError):
                continue
        
        for formato in formatos:
            try:
                return datetime.strptime(data_str, formato)
            except ValueError:
                continue
        
        return None

    async def _buscar_todos_tickets(self, data_inicio: str, data_fim: str) -> List[Dict]:
        """Retorna tickets filtrando por período usando filtro da API + fallback local"""
        try:
            data_inicio_obj = datetime.strptime(data_inicio, "%d/%m/%Y")
            data_fim_obj = datetime.strptime(data_fim, "%d/%m/%Y").replace(hour=23, minute=59, second=59)
        except Exception as e:
            logger.error(f"❌ Erro ao parsear datas do período: {e}")
            return []
        
        payload = {
            "Pesquisa": "",
            "Ordem": [{"Coluna": "DataCriacao", "Direcao": "false"}],
            "Filtro": {
                "DataCriacao": {
                    "Inicio": data_inicio,
                    "Fim": data_fim.replace("/", "/") + " 23:59:59"
                }
            }
        }
        
        response = await self.api_request('POST', '/ChamadosSuporte/lista', json=payload)
        
        if not response or response.get('erro'):
            logger.error(f"❌ Erro ao buscar tickets: {response.get('erro') if response else 'Sem resposta'}")
            return []
        
        todos_tickets = response.get('root', [])
        total_api_raw = response.get('total', len(todos_tickets))
        total_api = int(total_api_raw) if total_api_raw else len(todos_tickets)
        logger.info(f"📥 API retornou {len(todos_tickets)} de {total_api} tickets (filtro: {data_inicio} a {data_fim})")
        
        tickets_filtrados = []
        datas_nao_reconhecidas = 0
        
        for ticket in todos_tickets:
            data_str = ticket.get('DataCriacao', '')
            
            if not data_str:
                datas_nao_reconhecidas += 1
                continue
            
            data_obj = self._parse_date_flexible(data_str)
            
            if data_obj is None:
                datas_nao_reconhecidas += 1
                logger.debug(f"⚠️ Formato de data não reconhecido: '{data_str}'")
                continue
            
            if data_inicio_obj <= data_obj <= data_fim_obj:
                tickets_filtrados.append(ticket)
        
        if datas_nao_reconhecidas > 0:
            logger.warning(f"⚠️ {datas_nao_reconhecidas} tickets com data não reconhecida foram ignorados")
        
        limite_atingido = total_api > len(todos_tickets)
        if limite_atingido:
            logger.warning(f"⚠️ ATENÇÃO: API retornou apenas {len(todos_tickets)} de {total_api} tickets (limite da API)")
        
        logger.info(f"✅ Filtrados: {len(tickets_filtrados)} de {len(todos_tickets)} tickets no período {data_inicio} a {data_fim}")
        return tickets_filtrados

    async def _buscar_tickets_com_estatisticas(self, data_inicio: str, data_fim: str) -> tuple:
        """Retorna tickets e estatísticas sobre a consulta usando filtro server-side"""
        try:
            data_inicio_obj = datetime.strptime(data_inicio, "%d/%m/%Y")
            data_fim_obj = datetime.strptime(data_fim, "%d/%m/%Y").replace(hour=23, minute=59, second=59)
        except Exception as e:
            logger.error(f"❌ Erro ao parsear datas do período: {e}")
            return [], {"erro": str(e)}
        
        payload = {
            "Pesquisa": "",
            "Ordem": [{"Coluna": "DataCriacao", "Direcao": "false"}],
            "Filtro": {
                "DataCriacao": {
                    "Inicio": data_inicio,
                    "Fim": data_fim.replace("/", "/") + " 23:59:59"
                }
            }
        }
        
        response = await self.api_request('POST', '/ChamadosSuporte/lista', json=payload)
        
        if not response or response.get('erro'):
            return [], {"erro": response.get('erro') if response else 'Sem resposta'}
        
        todos_tickets = response.get('root', [])
        total_api_raw = response.get('total', len(todos_tickets))
        total_api = int(total_api_raw) if total_api_raw else len(todos_tickets)
        
        tickets_filtrados = []
        datas_nao_reconhecidas = 0
        
        for ticket in todos_tickets:
            data_str = ticket.get('DataCriacao', '')
            
            if not data_str:
                datas_nao_reconhecidas += 1
                continue
            
            data_obj = self._parse_date_flexible(data_str)
            
            if data_obj is None:
                datas_nao_reconhecidas += 1
                continue
            
            if data_inicio_obj <= data_obj <= data_fim_obj:
                tickets_filtrados.append(ticket)
        
        estatisticas = {
            "total_api": total_api,
            "retornados": len(todos_tickets),
            "filtrados": len(tickets_filtrados),
            "datas_invalidas": datas_nao_reconhecidas,
            "limite_atingido": total_api > len(todos_tickets),
            "data_inicio": data_inicio,
            "data_fim": data_fim
        }
        
        return tickets_filtrados, estatisticas

    @commands.command(name='relatorio-operadores')
    async def relatorio_por_operador(self, ctx: commands.Context, *, periodo: Optional[str] = None) -> None:
        """Relatório: Quantos chamados cada operador atendeu
        
        Períodos disponíveis:
        - `semestre` - Semestre atual (padrão)
        - `trimestre` - Trimestre atual
        - `mes` / `mês` - Mês atual
        - `semana` - Últimos 7 dias
        - `hoje` - Hoje
        
        Uso: `!relatorio-operadores` ou `!relatorio-operadores mês`
        """
        async with ctx.typing():
            from zoneinfo import ZoneInfo
            data_hora = datetime.now(ZoneInfo("America/Sao_Paulo")).strftime("%d/%m/%Y às %H:%M")
            
            data_inicio, data_fim, descricao_periodo = self._get_periodo_info(periodo)
            
            tickets, stats = await self._buscar_tickets_com_estatisticas(data_inicio, data_fim)
            
            if stats.get("erro"):
                await ctx.send(f"❌ Erro ao buscar dados: {stats['erro']}")
                return
            
            if not tickets:
                await ctx.send(f"📋 Nenhum ticket encontrado no período: **{descricao_periodo}** ({data_inicio} a {data_fim})")
                return
            
            operadores = {}
            for ticket in tickets:
                nome_operador = ticket.get('NomeOperador', '') or ''
                sobrenome_operador = ticket.get('SobrenomeOperador', '') or ''
                operador_completo = f"{nome_operador} {sobrenome_operador}".strip()
                
                if not operador_completo:
                    operador_completo = "Não atribuído"
                
                operadores[operador_completo] = operadores.get(operador_completo, 0) + 1
            
            operadores_ordenado = sorted(operadores.items(), key=lambda x: x[1], reverse=True)
            
            descricao = f"📅 **Período:** {descricao_periodo}\n"
            descricao += f"📆 **De:** {data_inicio} **até:** {data_fim}\n"
            descricao += f"🕐 **Atualizado:** {data_hora}"
            
            if stats["limite_atingido"]:
                descricao += f"\n\n⚠️ **ATENÇÃO:** A API Desk.ms retornou {stats['retornados']} de {stats['total_api']} tickets. Os dados podem estar incompletos!"
            
            embed = discord.Embed(
                title="📊 Relatório: Chamados por Operador",
                description=descricao,
                color=discord.Color.orange() if stats["limite_atingido"] else discord.Color.gold()
            )
            
            total_tickets = len(tickets)
            media_por_operador = total_tickets / len(operadores) if operadores else 0
            
            embed.add_field(name="📋 Total de Chamados", value=str(total_tickets), inline=True)
            embed.add_field(name="👥 Operadores Ativos", value=str(len(operadores)), inline=True)
            embed.add_field(name="📈 Média/Operador", value=f"{media_por_operador:.1f}", inline=True)
            
            operadores_text = ""
            medalhas = ["🥇", "🥈", "🥉"]
            for i, (operador, count) in enumerate(operadores_ordenado[:15]):
                percentual = (count / total_tickets) * 100
                medalha = medalhas[i] if i < 3 else "👤"
                operadores_text += f"{medalha} **{operador}**: {count} ({percentual:.1f}%)\n"
            
            if operadores_text:
                embed.add_field(name="🏆 Ranking", value=operadores_text, inline=False)
            
            footer_text = f"Período: {data_inicio} a {data_fim}"
            if stats["datas_invalidas"] > 0:
                footer_text += f" | ⚠️ {stats['datas_invalidas']} registros ignorados (data inválida)"
            
            embed.set_footer(text=footer_text)
            await ctx.send(embed=embed)

    @commands.command(name='relatorio-resumo')
    async def relatorio_resumo(self, ctx: commands.Context, *, periodo: Optional[str] = None) -> None:
        """Relatório: Resumo geral de tickets por status
        
        Períodos disponíveis:
        - `semestre` - Semestre atual (padrão)
        - `trimestre` - Trimestre atual
        - `mes` / `mês` - Mês atual
        - `semana` - Últimos 7 dias
        - `hoje` - Hoje
        
        Uso: `!relatorio-resumo` ou `!relatorio-resumo mês`
        """
        async with ctx.typing():
            from zoneinfo import ZoneInfo
            data_hora = datetime.now(ZoneInfo("America/Sao_Paulo")).strftime("%d/%m/%Y às %H:%M")
            
            data_inicio, data_fim, descricao_periodo = self._get_periodo_info(periodo)
            
            tickets, stats = await self._buscar_tickets_com_estatisticas(data_inicio, data_fim)
            
            if stats.get("erro"):
                await ctx.send(f"❌ Erro ao buscar dados: {stats['erro']}")
                return
            
            if not tickets:
                await ctx.send(f"📋 Nenhum ticket encontrado no período: **{descricao_periodo}** ({data_inicio} a {data_fim})")
                return
            
            status_count = {}
            prioridade_count = {}
            resolvidos = 0
            em_aberto = 0
            
            for ticket in tickets:
                nome_status = ticket.get('NomeStatus', [])
                if isinstance(nome_status, list) and nome_status:
                    status_text = nome_status[0].get('text', 'Desconhecido')
                else:
                    status_text = str(nome_status) if nome_status else 'Desconhecido'
                
                prioridade = ticket.get('NomePrioridade', 'Não definida')
                
                status_count[status_text] = status_count.get(status_text, 0) + 1
                prioridade_count[prioridade] = prioridade_count.get(prioridade, 0) + 1
                
                status_lower = status_text.lower()
                if any(x in status_lower for x in ['resolvido', 'finalizado', 'encerrado', 'fechado']):
                    resolvidos += 1
                elif not any(x in status_lower for x in ['cancelado', 'rejeitado']):
                    em_aberto += 1
            
            descricao = f"📅 **Período:** {descricao_periodo}\n"
            descricao += f"📆 **De:** {data_inicio} **até:** {data_fim}\n"
            descricao += f"🕐 **Atualizado:** {data_hora}"
            
            if stats["limite_atingido"]:
                descricao += f"\n\n⚠️ **ATENÇÃO:** A API Desk.ms retornou {stats['retornados']} de {stats['total_api']} tickets. Os dados podem estar incompletos!"
            
            embed = discord.Embed(
                title="📈 Relatório: Resumo de Tickets",
                description=descricao,
                color=discord.Color.orange() if stats["limite_atingido"] else discord.Color.blue()
            )
            
            total = len(tickets)
            taxa_resolucao = (resolvidos / total * 100) if total > 0 else 0
            
            embed.add_field(name="📋 Total", value=str(total), inline=True)
            embed.add_field(name="✅ Resolvidos", value=str(resolvidos), inline=True)
            embed.add_field(name="🔧 Em Aberto", value=str(em_aberto), inline=True)
            embed.add_field(name="📊 Taxa Resolução", value=f"{taxa_resolucao:.1f}%", inline=True)
            
            status_text_embed = ""
            status_emojis = {
                'resolvido': '✅', 'finalizado': '✅', 'encerrado': '✅', 'fechado': '✅',
                'novo': '🆕', 'aberto': '🆕',
                'andamento': '🔧', 'atendimento': '🔧', 'aguardando': '⏳',
                'cancelado': '❌', 'rejeitado': '❌'
            }
            
            for status, count in sorted(status_count.items(), key=lambda x: x[1], reverse=True)[:10]:
                emoji = '📌'
                for key, emj in status_emojis.items():
                    if key in status.lower():
                        emoji = emj
                        break
                percentual = (count / total) * 100
                status_text_embed += f"{emoji} **{status}**: {count} ({percentual:.1f}%)\n"
            
            if status_text_embed:
                embed.add_field(name="📊 Por Status", value=status_text_embed, inline=False)
            
            prioridade_text = ""
            prioridade_emojis = {'alta': '🔴', 'média': '🟡', 'media': '🟡', 'baixa': '🟢', 'crítica': '🚨', 'critica': '🚨'}
            
            for prioridade, count in sorted(prioridade_count.items(), key=lambda x: x[1], reverse=True):
                emoji = '⚪'
                for key, emj in prioridade_emojis.items():
                    if key in prioridade.lower():
                        emoji = emj
                        break
                percentual = (count / total) * 100
                prioridade_text += f"{emoji} **{prioridade}**: {count} ({percentual:.1f}%)\n"
            
            if prioridade_text:
                embed.add_field(name="🎯 Por Prioridade", value=prioridade_text, inline=False)
            
            footer_text = f"Período: {data_inicio} a {data_fim}"
            if stats["datas_invalidas"] > 0:
                footer_text += f" | ⚠️ {stats['datas_invalidas']} registros ignorados"
            
            embed.set_footer(text=footer_text)
            await ctx.send(embed=embed)

    async def periodo_autocomplete(self, interaction: discord.Interaction, current: str) -> List[app_commands.Choice[str]]:
        periodos = [
            ("Semestre atual", "semestre"),
            ("Trimestre atual", "trimestre"),
            ("Mes atual", "mes"),
            ("Ultimos 7 dias", "semana"),
            ("Hoje", "hoje")
        ]
        
        if current:
            periodos = [(nome, valor) for nome, valor in periodos if current.lower() in nome.lower()]
        
        return [app_commands.Choice(name=nome, value=valor) for nome, valor in periodos]

    @app_commands.command(name="tickets", description="Listar tickets do Desk.ms")
    @app_commands.describe(filtro="Filtrar por status (opcional)")
    async def slash_tickets(self, interaction: discord.Interaction, filtro: Optional[str] = None):
        await interaction.response.defer()
        
        payload = {
            "Pesquisa": "",
            "Ordem": [{"Coluna": "DataCriacao", "Direcao": "false"}]
        }
        response = await self.api_request('POST', '/ChamadosSuporte/lista', json=payload)
        
        if not response or response.get('erro'):
            erro = response.get('erro') if response else "Nenhum ticket encontrado"
            return await interaction.followup.send(f"❌ {erro}")
        
        todos_tickets = response.get('root', [])
        
        if not todos_tickets:
            return await interaction.followup.send("📋 Nenhum ticket encontrado.")
        
        if filtro:
            filtro_lower = filtro.lower()
            tickets_filtrados = []
            for ticket in todos_tickets:
                nome_status = ticket.get('NomeStatus', [])
                if isinstance(nome_status, list) and nome_status:
                    status_text = nome_status[0].get('text', '').lower()
                else:
                    status_text = str(nome_status).lower() if nome_status else ''
                
                if filtro_lower in status_text:
                    tickets_filtrados.append(ticket)
            
            if not tickets_filtrados:
                return await interaction.followup.send(f"📋 Nenhum ticket com status `{filtro}`")
            
            tickets_final = tickets_filtrados[:25]
            titulo = f"🔍 Tickets com Status '{filtro}' ({len(tickets_final)})"
        else:
            tickets_abertos = []
            for ticket in todos_tickets:
                nome_status = ticket.get('NomeStatus', [])
                if isinstance(nome_status, list) and nome_status:
                    status_text = nome_status[0].get('text', '').lower()
                else:
                    status_text = str(nome_status).lower() if nome_status else ''
                
                if not any(x in status_text for x in ['resolvido', 'finalizado', 'encerrado', 'fechado', 'cancelado', 'rejeitado']):
                    tickets_abertos.append(ticket)
            
            if not tickets_abertos:
                return await interaction.followup.send("✅ Nenhum ticket em aberto! Parabens!")
            
            tickets_final = tickets_abertos[:25]
            titulo = f"🆕 Tickets em Aberto ({len(tickets_final)})"
        
        embed = discord.Embed(title=titulo, color=discord.Color.blue())
        
        for ticket in tickets_final[:15]:
            id_ticket = str(ticket.get('CodChamado', 'N/A'))
            assunto = ticket.get('Assunto', 'Sem assunto')[:50]
            nome_status = ticket.get('NomeStatus', [])
            status = nome_status[0].get('text', '---') if isinstance(nome_status, list) and nome_status else '---'
            prioridade = ticket.get('NomePrioridade', '---')
            
            embed.add_field(
                name=f"#{id_ticket} - {assunto}",
                value=f"**Status:** {status} | **Prioridade:** {prioridade}",
                inline=False
            )
        
        if len(tickets_final) > 15:
            embed.set_footer(text=f"Mostrando 15 de {len(tickets_final)} tickets | Use /ticket [ID] para detalhes")
        else:
            embed.set_footer(text="Use /ticket [ID] para mais detalhes")
        
        await interaction.followup.send(embed=embed)

    @app_commands.command(name="ticket", description="Ver detalhes de um ticket")
    @app_commands.describe(id="ID do ticket")
    async def slash_ticket(self, interaction: discord.Interaction, id: str):
        await interaction.response.defer()
        
        payload = {
            "Pesquisa": id,
            "Ordem": [{"Coluna": "DataCriacao", "Direcao": "false"}]
        }
        response = await self.api_request('POST', '/ChamadosSuporte/lista', json=payload)
        
        if not response:
            return await interaction.followup.send("❌ Erro ao conectar com a API")
        
        tickets = response.get('root', [])
        
        data = None
        ticket_id_clean = id.replace('-', '').lower().strip()
        
        for ticket in tickets:
            cod = str(ticket.get('CodChamado', '')).lower().replace('-', '')
            if ticket_id_clean in cod or cod in ticket_id_clean:
                data = ticket
                break
        
        if not data:
            return await interaction.followup.send(f"❌ Ticket `{id}` nao encontrado")
        
        assunto = data.get('Assunto', 'Sem assunto')
        nome_status = data.get('NomeStatus', '')
        if isinstance(nome_status, list) and nome_status:
            status = nome_status[0].get('text', 'Desconhecido')
        else:
            status = str(nome_status) if nome_status else 'Desconhecido'
        
        nome_usuario = data.get('NomeUsuario', '')
        sobrenome_usuario = data.get('SobrenomeUsuario', '')
        cliente = f"{nome_usuario} {sobrenome_usuario}".strip() or 'Nao informado'
        
        prioridade = data.get('NomePrioridade', '---')
        
        nome_operador = data.get('NomeOperador', '')
        sobrenome_operador = data.get('SobrenomeOperador', '')
        analista = f"{nome_operador} {sobrenome_operador}".strip() or 'Nao atribuido'
        
        data_criacao = data.get('DataCriacao', '---')
        
        status_lower = status.lower()
        if any(x in status_lower for x in ['resolvido', 'finalizado', 'encerrado']):
            emoji, cor = "✅", discord.Color.green()
        elif any(x in status_lower for x in ['cancelado', 'rejeitado']):
            emoji, cor = "❌", discord.Color.red()
        elif any(x in status_lower for x in ['andamento', 'atendimento']):
            emoji, cor = "🔧", discord.Color.orange()
        else:
            emoji, cor = "🆕", discord.Color.blue()
        
        embed = discord.Embed(
            title=f"Ticket #{id}",
            description=f"{emoji} **{assunto}**",
            color=cor
        )
        embed.add_field(name="📌 Status", value=status, inline=True)
        embed.add_field(name="🎯 Prioridade", value=prioridade, inline=True)
        embed.add_field(name="👤 Cliente", value=cliente, inline=False)
        embed.add_field(name="👨‍💻 Analista", value=analista, inline=True)
        embed.add_field(name="📅 Criado em", value=data_criacao, inline=True)
        
        await interaction.followup.send(embed=embed)

    @app_commands.command(name="relatorio", description="Gerar relatorio de tickets")
    @app_commands.describe(
        tipo="Tipo de relatorio",
        periodo="Periodo do relatorio"
    )
    @app_commands.choices(tipo=[
        app_commands.Choice(name="Resumo por Status", value="resumo"),
        app_commands.Choice(name="Por Operador", value="operadores")
    ])
    @app_commands.autocomplete(periodo=periodo_autocomplete)
    async def slash_relatorio(self, interaction: discord.Interaction, tipo: str = "resumo", periodo: str = "semestre"):
        await interaction.response.defer()
        
        from zoneinfo import ZoneInfo
        data_hora = datetime.now(ZoneInfo("America/Sao_Paulo")).strftime("%d/%m/%Y as %H:%M")
        
        data_inicio, data_fim, descricao_periodo = self._get_periodo_info(periodo)
        
        tickets, stats = await self._buscar_tickets_com_estatisticas(data_inicio, data_fim)
        
        if stats.get("erro"):
            return await interaction.followup.send(f"❌ Erro ao buscar dados: {stats['erro']}")
        
        if not tickets:
            return await interaction.followup.send(f"📋 Nenhum ticket encontrado no periodo: **{descricao_periodo}**")
        
        if tipo == "operadores":
            operadores = {}
            for ticket in tickets:
                nome_operador = ticket.get('NomeOperador', '') or ''
                sobrenome_operador = ticket.get('SobrenomeOperador', '') or ''
                operador_completo = f"{nome_operador} {sobrenome_operador}".strip()
                
                if not operador_completo:
                    operador_completo = "Nao atribuido"
                
                operadores[operador_completo] = operadores.get(operador_completo, 0) + 1
            
            operadores_ordenado = sorted(operadores.items(), key=lambda x: x[1], reverse=True)
            
            descricao = f"📅 **Periodo:** {descricao_periodo}\n"
            descricao += f"📆 **De:** {data_inicio} **ate:** {data_fim}\n"
            descricao += f"🕐 **Atualizado:** {data_hora}"
            
            if stats["limite_atingido"]:
                descricao += f"\n\n⚠️ **ATENCAO:** API retornou {stats['retornados']} de {stats['total_api']} tickets"
            
            embed = discord.Embed(
                title="📊 Relatorio: Chamados por Operador",
                description=descricao,
                color=discord.Color.orange() if stats["limite_atingido"] else discord.Color.gold()
            )
            
            total_tickets = len(tickets)
            media = total_tickets / len(operadores) if operadores else 0
            
            embed.add_field(name="📋 Total", value=str(total_tickets), inline=True)
            embed.add_field(name="👥 Operadores", value=str(len(operadores)), inline=True)
            embed.add_field(name="📈 Media", value=f"{media:.1f}", inline=True)
            
            operadores_text = ""
            medalhas = ["🥇", "🥈", "🥉"]
            for i, (operador, count) in enumerate(operadores_ordenado[:15]):
                percentual = (count / total_tickets) * 100
                medalha = medalhas[i] if i < 3 else "👤"
                operadores_text += f"{medalha} **{operador}**: {count} ({percentual:.1f}%)\n"
            
            if operadores_text:
                embed.add_field(name="🏆 Ranking", value=operadores_text, inline=False)
        else:
            status_count = {}
            resolvidos = 0
            em_aberto = 0
            
            for ticket in tickets:
                nome_status = ticket.get('NomeStatus', [])
                if isinstance(nome_status, list) and nome_status:
                    status_text = nome_status[0].get('text', 'Desconhecido')
                else:
                    status_text = str(nome_status) if nome_status else 'Desconhecido'
                
                status_count[status_text] = status_count.get(status_text, 0) + 1
                
                status_lower = status_text.lower()
                if any(x in status_lower for x in ['resolvido', 'finalizado', 'encerrado', 'fechado']):
                    resolvidos += 1
                elif not any(x in status_lower for x in ['cancelado', 'rejeitado']):
                    em_aberto += 1
            
            descricao = f"📅 **Periodo:** {descricao_periodo}\n"
            descricao += f"📆 **De:** {data_inicio} **ate:** {data_fim}\n"
            descricao += f"🕐 **Atualizado:** {data_hora}"
            
            if stats["limite_atingido"]:
                descricao += f"\n\n⚠️ **ATENCAO:** API retornou {stats['retornados']} de {stats['total_api']} tickets"
            
            embed = discord.Embed(
                title="📈 Relatorio: Resumo de Tickets",
                description=descricao,
                color=discord.Color.orange() if stats["limite_atingido"] else discord.Color.blue()
            )
            
            total = len(tickets)
            taxa = (resolvidos / total * 100) if total > 0 else 0
            
            embed.add_field(name="📋 Total", value=str(total), inline=True)
            embed.add_field(name="✅ Resolvidos", value=str(resolvidos), inline=True)
            embed.add_field(name="🔧 Em Aberto", value=str(em_aberto), inline=True)
            embed.add_field(name="📊 Taxa Resolucao", value=f"{taxa:.1f}%", inline=True)
            
            status_text_embed = ""
            for status, count in sorted(status_count.items(), key=lambda x: x[1], reverse=True)[:10]:
                percentual = (count / total) * 100
                status_text_embed += f"📌 **{status}**: {count} ({percentual:.1f}%)\n"
            
            if status_text_embed:
                embed.add_field(name="📊 Por Status", value=status_text_embed, inline=False)
        
        await interaction.followup.send(embed=embed)

    @app_commands.command(name="desk-status", description="Verificar status da conexao com Desk.ms")
    async def slash_desk_status(self, interaction: discord.Interaction):
        await interaction.response.defer()
        
        embed = discord.Embed(
            title="🔍 Status da Conexao Desk.ms",
            color=discord.Color.blue()
        )
        
        has_keys = bool(self.operator_key and self.environment_key)
        embed.add_field(
            name="🔑 Chaves Configuradas",
            value="✅ Sim" if has_keys else "❌ Nao",
            inline=True
        )
        
        if has_keys:
            token = await self.get_auth_token()
            if token:
                embed.add_field(name="🔐 Autenticacao", value="✅ OK", inline=True)
                embed.add_field(
                    name="⏰ Token Expira",
                    value=self.token_expires.strftime("%H:%M:%S") if self.token_expires else "N/A",
                    inline=True
                )
                embed.color = discord.Color.green()
            else:
                embed.add_field(name="🔐 Autenticacao", value="❌ Falhou", inline=True)
                embed.color = discord.Color.red()
        
        embed.add_field(name="🌐 API URL", value=self.base_url, inline=False)
        await interaction.followup.send(embed=embed)


async def setup(bot):
    cog = DeskCog(bot)
    await bot.add_cog(cog)
    logger.info("Cog Desk carregado com sucesso")
